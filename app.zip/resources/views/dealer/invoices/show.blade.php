@extends('layouts.dealer')
@section('title', $invoice->number)
@section('actions')
    <a class="btn smallbtn ghost" href="{{ route('dealer.invoices.print', $invoice) }}" target="_blank">Print</a>
@endsection
@section('content')
<div class="panel">
    <p>{{ str_replace('_', ' ', $invoice->kind) }} · {{ str_replace('_', ' ', $invoice->vat_scheme) }} · {{ str_replace('_', ' ', $invoice->status) }}</p>
    <p>{{ $invoice->customer_snapshot['name'] ?? '' }} · {{ $invoice->customer_snapshot['email'] ?? '' }}</p>
    <p>{{ $invoice->vehicle_snapshot['label'] ?? '' }} {{ $invoice->vehicle_snapshot['registration'] ?? '' }}</p>
    <div class="table-scroll">
        <table class="data-table">
            <thead>
                <tr><th class="sno">S.no</th><th>Description</th><th>Qty</th><th class="num">Net</th><th class="num">VAT</th><th class="num">Total</th></tr>
            </thead>
            <tbody>
                @foreach ($invoice->lines as $line)
                    <tr>
                        <td class="sno">{{ $loop->iteration }}</td>
                        <td>{{ $line->description }} <small>{{ ucfirst(str_replace('_',' ', $line->line_type)) }}</small></td>
                        <td>{{ $line->quantity }}</td>
                        <td class="num">@gbp($line->unit_net_pence)</td>
                        <td class="num">@gbp($line->vat_pence)</td>
                        <td class="num">@gbp($line->line_total_pence)</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>
    <p>Net @gbp($invoice->net_pence) · VAT @gbp($invoice->vat_pence) · Total @gbp($invoice->total_pence)</p>
    <p>Balance @gbp($invoice->balancePence())</p>
    @if ($invoice->payments->isNotEmpty())
        <h2>Payments</h2>
        <div class="table-scroll">
            <table class="data-table">
                <thead>
                    <tr><th class="sno">S.no</th><th>Date</th><th class="num">Amount</th><th>Method</th><th>Reference</th></tr>
                </thead>
                <tbody>
                    @foreach ($invoice->payments as $payment)
                        <tr>
                            <td class="sno">{{ $loop->iteration }}</td>
                            <td>{{ $payment->received_on?->format('j M Y') }}</td>
                            <td class="num">@gbp($payment->amount_pence)</td>
                            <td>{{ ucfirst(str_replace('_', ' ', $payment->method)) }}</td>
                            <td>{{ $payment->reference }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>
@if (auth('staff')->user()->can('invoices.manage'))
    <div class="row" style="margin-top:1rem;">
        @if ($invoice->status === 'draft')
            <form method="post" action="{{ route('dealer.invoices.issue', $invoice) }}">@csrf<button class="btn" type="submit">Issue</button></form>
        @endif
        @if (in_array($invoice->status, ['draft','issued']) && $invoice->payments->isEmpty())
            <form method="post" action="{{ route('dealer.invoices.void', $invoice) }}">@csrf<button class="btn danger" type="submit">Void</button></form>
        @endif
        @if ($invoice->kind === 'invoice' && in_array($invoice->status, ['issued','part_paid','paid']))
            <form method="post" action="{{ route('dealer.invoices.credit', $invoice) }}">@csrf<button class="btn secondary" type="submit">Credit note</button></form>
        @endif
    </div>
    @if (in_array($invoice->status, ['issued','part_paid']) && $invoice->kind === 'invoice')
        <form class="panel" method="post" action="{{ route('dealer.invoices.pay', $invoice) }}" style="margin-top:1rem;">
            @csrf
            <h2>Record a payment</h2>
            <div class="row">
                <input name="amount" type="number" step="0.01" placeholder="Amount £" required>
                <input type="date" name="received_on" required value="{{ now()->toDateString() }}">
                <select name="method">@foreach (['bank_transfer','card','finance','cash'] as $method)<option value="{{ $method }}">{{ str_replace('_',' ', $method) }}</option>@endforeach</select>
                <input name="reference" placeholder="Reference" required>
            </div>
            <button class="btn" type="submit" style="margin-top:.6rem;">Save payment</button>
        </form>
    @endif
@endif
@endsection
