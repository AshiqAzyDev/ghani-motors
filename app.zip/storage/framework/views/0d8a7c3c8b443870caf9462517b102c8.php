<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <title>Dealer log in | Ghani Motors</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Manrope:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/upgrades.css')); ?>">
</head>
<body class="auth-body">
<main class="auth-shell">
    <aside class="auth-aside">
        <p class="wordmark">GHANI <span>MOTORS</span></p>
        <p class="auth-kicker">Dealer workspace</p>
        <h1>Sign in to manage stock, bookings and invoices.</h1>
        <p>Quality used cars, Rainham Road South, Dagenham.</p>
        <?php echo $__env->make('partials.aa-badge', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <a class="auth-back" href="<?php echo e(route('home')); ?>">← Back to website</a>
    </aside>
    <section class="auth-card">
        <form method="post" action="<?php echo e(route('dealer.login.store')); ?>">
            <?php echo csrf_field(); ?>
            <h2>Log in</h2>
            <p class="meta">Use your staff email and password.</p>
            <?php if($errors->any()): ?><div class="errors"><?php echo e($errors->first()); ?></div><?php endif; ?>
            <label for="email">Email</label>
            <input id="email" type="email" name="email" required autocomplete="username" value="<?php echo e(old('email')); ?>">
            <?php echo $__env->make('partials.password-field', ['id' => 'password'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <p class="meta" style="margin-top:8px;"><a href="<?php echo e(route('dealer.password.request')); ?>">Forgot password?</a></p>
            <button class="btn" type="submit">Log in</button>
        </form>
    </section>
</main>
<script src="<?php echo e(asset('js/site.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/login.blade.php ENDPATH**/ ?>