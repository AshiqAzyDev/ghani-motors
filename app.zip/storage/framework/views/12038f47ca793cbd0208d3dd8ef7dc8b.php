
<?php $__env->startSection('title', 'Staff'); ?>
<?php $__env->startSection('content'); ?>
<?php ($canAssignAdmin = $canAssignAdmin ?? false); ?>
<p class="page-note">Invite staff and control what each person can do in the dealer workspace.</p>

<section class="panel" data-staff-perms data-presets='<?php echo json_encode($permissionPresets, 15, 512) ?>'>
    <h2>Invite staff</h2>
    <form method="post" action="<?php echo e(route('dealer.staff.store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="row">
            <input name="name" placeholder="Name" required value="<?php echo e(old('name')); ?>">
            <input type="email" name="email" placeholder="Email" required value="<?php echo e(old('email')); ?>">
            <select name="role" data-role-preset>
                <option value="sales" <?php if(old('role', 'sales') === 'sales'): echo 'selected'; endif; ?>>Sales</option>
                <option value="viewer" <?php if(old('role') === 'viewer'): echo 'selected'; endif; ?>>Viewer</option>
                <?php if($canAssignAdmin): ?>
                    <option value="admin" <?php if(old('role') === 'admin'): echo 'selected'; endif; ?>>Admin</option>
                <?php endif; ?>
            </select>
        </div>
        <div class="perm-grid" data-perm-grid style="<?php echo \Illuminate\Support\Arr::toCssStyles(['display: none' => old('role') === 'admin']) ?>">
            <?php $__currentLoopData = $permissionLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <label class="check-inline"><input type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" <?php if(in_array($key, old('permissions', \App\Support\StaffPermissions::preset(old('role', 'sales'))), true)): echo 'checked'; endif; ?>> <?php echo e($label); ?></label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <p class="meta" data-admin-note style="<?php echo \Illuminate\Support\Arr::toCssStyles(['display: none' => old('role') !== 'admin']) ?>">Admins always have full access. Permission checkboxes are not used.</p>
        <button class="btn" type="submit" style="margin-top:.75rem;">Send invite</button>
    </form>
</section>

<?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php ($editableRoles = $canAssignAdmin || $member->role === 'admin' ? ['admin', 'sales', 'viewer'] : ['sales', 'viewer']); ?>
    <section class="panel" style="margin-top:1rem;" data-staff-perms data-presets='<?php echo json_encode($permissionPresets, 15, 512) ?>'>
        <h2><?php echo e($member->name); ?> <small class="meta"><?php echo e($member->email); ?> · <?php echo e($member->role); ?> · <?php echo e($member->is_active ? 'active' : 'inactive'); ?></small></h2>
        <form method="post" action="<?php echo e(route('dealer.staff.update', $member)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="row">
                <input name="name" value="<?php echo e(old('name', $member->name)); ?>" required>
                <select name="role" data-role-preset <?php if(! $canAssignAdmin && $member->role === 'admin'): echo 'disabled'; endif; ?>>
                    <?php $__currentLoopData = $editableRoles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($role); ?>" <?php if(old('role', $member->role) === $role): echo 'selected'; endif; ?>><?php echo e(ucfirst($role)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php if(! $canAssignAdmin && $member->role === 'admin'): ?>
                    <input type="hidden" name="role" value="admin">
                <?php endif; ?>
                <input type="hidden" name="is_active" value="0">
                <label class="check-inline"><input type="checkbox" name="is_active" value="1" <?php if((string) old('is_active', $member->is_active ? '1' : '0') === '1'): echo 'checked'; endif; ?>> Active</label>
            </div>
            <div class="perm-grid" data-perm-grid style="<?php echo \Illuminate\Support\Arr::toCssStyles(['display: none' => old('role', $member->role) === 'admin']) ?>">
                <?php $__currentLoopData = $permissionLabels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label class="check-inline"><input type="checkbox" name="permissions[]" value="<?php echo e($key); ?>" <?php if(in_array($key, old('permissions', $member->permissionList()), true)): echo 'checked'; endif; ?>> <?php echo e($label); ?></label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <p class="meta" data-admin-note style="<?php echo \Illuminate\Support\Arr::toCssStyles(['display: none' => old('role', $member->role) !== 'admin']) ?>">Admins always have full access.</p>
            <button class="btn smallbtn" type="submit" style="margin-top:.75rem;">Save</button>
        </form>
        <form method="post" action="<?php echo e(route('dealer.staff.invite', $member)); ?>" style="margin-top:.5rem;"><?php echo csrf_field(); ?><button class="rowbtn" type="submit">Resend invite / password link</button></form>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/staff/index.blade.php ENDPATH**/ ?>