<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>All enquiries</h2>
            <p class="meta">Page <?php echo e($leads->currentPage()); ?> of <?php echo e(max($leads->lastPage(), 1)); ?></p>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="account-item">
            <div>
                <b><?php echo e($lead->subject); ?></b>
                <p class="meta">
                    <?php if($lead->vehicle?->slug): ?>
                        <a href="<?php echo e(route('cars.show', $lead->vehicle->slug)); ?>"><?php echo e($lead->vehicle->title()); ?></a> ·
                    <?php endif; ?>
                    <?php echo e(ucfirst(str_replace('_', ' ', $lead->type))); ?>

                </p>
                <small><?php echo e($lead->created_on?->format('j M Y') ?? $lead->created_at?->format('j M Y')); ?></small>
            </div>
            <span class="badge <?php echo e($lead->status); ?>"><?php echo e(ucfirst($lead->status)); ?></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="account-empty">
            <p>No enquiries yet.</p>
            <a class="btn" href="<?php echo e(route('stock')); ?>">Ask about a car</a>
        </div>
    <?php endif; ?>
    <div class="account-pager"><?php echo e($leads->links()); ?></div>
</section>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account/enquiries.blade.php ENDPATH**/ ?>