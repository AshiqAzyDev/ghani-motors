<?php ($user = auth()->user()); ?>
<label>Name</label>
<input name="name" required value="<?php echo e(old('name', $user->name ?? '')); ?>">
<label>Email</label>
<input type="email" name="email" required value="<?php echo e(old('email', $user->email ?? '')); ?>">
<label>Phone</label>
<input name="phone" required value="<?php echo e(old('phone', $user->phone ?? '')); ?>">
<label><input type="checkbox" name="accepted_terms" value="1" required style="width:auto;"> I accept the <a href="<?php echo e(route('privacy')); ?>">privacy terms</a></label>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/partials/contact-fields.blade.php ENDPATH**/ ?>