<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>Invoices</h2>
            <p class="meta">Page <?php echo e($invoices->currentPage()); ?> of <?php echo e(max($invoices->lastPage(), 1)); ?></p>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="account-item">
            <div>
                <b><?php echo e($invoice->number); ?></b>
                <p class="meta"><?php echo e(\App\Support\Money::gbp($invoice->total_pence)); ?> · <?php echo e(ucfirst(str_replace('_', ' ', $invoice->kind))); ?></p>
            </div>
            <span class="badge <?php echo e($invoice->status); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $invoice->status))); ?></span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="account-empty compact"><p>No invoices yet.</p></div>
    <?php endif; ?>
    <div class="account-pager"><?php echo e($invoices->links()); ?></div>
</section>

<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>Purchases</h2>
            <p class="meta">Completed sales on your account.</p>
        </div>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="account-item">
            <div>
                <b><?php echo e($sale->vehicle?->title() ?: $sale->vehicle_label); ?></b>
                <p class="meta"><?php echo e($sale->sold_on?->format('j M Y')); ?> · <?php echo e(\App\Support\Money::gbp($sale->price_pence)); ?></p>
            </div>
            <span class="badge completed">Completed</span>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="account-empty compact"><p>No purchases yet.</p></div>
    <?php endif; ?>
    <div class="account-pager"><?php echo e($sales->links()); ?></div>
</section>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account/invoices.blade.php ENDPATH**/ ?>