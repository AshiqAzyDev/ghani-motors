<?php
    $price = $car->publicPricePence();
    $pounds = $price !== null ? intdiv($price, 100) : null;
    $monthly = null;
    if ($pounds !== null) {
        $rate = 0.129 / 12;
        $payment = ($pounds * 0.9) * $rate / (1 - pow(1 + $rate, -48));
        $monthly = is_finite($payment) ? (int) round($payment) : null;
    }
    $plate = strtoupper(preg_replace('/\s+/', '', (string) $car->registration) ?? '');
    if (strlen($plate) === 7) {
        $plate = substr($plate, 0, 4).' '.substr($plate, 4);
    }
    $gear = (string) $car->transmission;
    if (str_contains(strtolower($gear), 'automatic')) {
        $gear = 'Auto';
    }
    $image = $car->images->first();
    $photos = $car->images->count();
    $milesFull = $car->mileage !== null ? number_format((int) $car->mileage) : '—';
    $milesShort = $car->mileage !== null
        ? (abs((int) $car->mileage) >= 1000
            ? number_format((int) round(((int) $car->mileage) / 1000)).'k'
            : number_format((int) $car->mileage))
        : '—';
?>
<article class="<?php echo \Illuminate\Support\Arr::toCssClasses(['stock-card', 'is-featured' => $car->featured]); ?>">
    <div>
        <div class="stock-media-wrap">
        <a class="stock-media" href="<?php echo e(route('cars.show', $car->slug)); ?>" aria-label="View <?php echo e($car->title()); ?>">
            <?php if($image): ?>
                <img src="<?php echo e($image->sized('w800h600')); ?>" alt="<?php echo e($car->title()); ?>">
            <?php else: ?>
                <span class="stock-media-empty">Photo to follow</span>
            <?php endif; ?>
            <span class="stock-badges">
                <span class="stock-status <?php echo e($car->website_status); ?>"><?php echo e(ucfirst($car->website_status)); ?></span>
                <?php if($car->featured): ?>
                    <span class="stock-featured">Featured</span>
                <?php endif; ?>
            </span>
            <span class="stock-media-meta">
                <?php if($plate !== ''): ?>
                    <span class="stock-reg-pill">Reg <?php echo e($plate); ?></span>
                <?php endif; ?>
                <?php if($photos > 0): ?>
                    <span class="stock-photos">1 / <?php echo e($photos); ?></span>
                <?php endif; ?>
            </span>
        </a>
        <?php if(auth()->guard()->check()): ?>
            <form method="post" action="<?php echo e(route('cars.save', $car->slug)); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" data-save="<?php echo e($car->id); ?>" aria-label="Save <?php echo e($car->title()); ?>">
                    <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20s-7-4.4-9.2-8.2C1 8.8 2.2 5.6 5.4 4.8 7.4 4.3 9.3 5.2 12 8c2.7-2.8 4.6-3.7 6.6-3.2 3.2.8 4.4 4 2.6 7-2.2 3.8-9.2 8.2-9.2 8.2z"></path></svg>
                </button>
            </form>
        <?php else: ?>
            <a class="stock-save-login" href="<?php echo e(route('login', ['redirect' => route('cars.show', $car->slug, false)])); ?>" aria-label="Log in to save <?php echo e($car->title()); ?>">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20s-7-4.4-9.2-8.2C1 8.8 2.2 5.6 5.4 4.8 7.4 4.3 9.3 5.2 12 8c2.7-2.8 4.6-3.7 6.6-3.2 3.2.8 4.4 4 2.6 7-2.2 3.8-9.2 8.2-9.2 8.2z" fill="none" stroke="currentColor" stroke-width="1.8"></path></svg>
            </a>
        <?php endif; ?>
        </div>
        <div class="stock-copy">
            <div class="stock-regline">
                <?php if($plate !== ''): ?><span>Reg <?php echo e($plate); ?></span><?php endif; ?>
            </div>
            <h3><a href="<?php echo e(route('cars.show', $car->slug)); ?>"><?php echo e($car->make); ?> <?php echo e($car->model); ?></a></h3>
            <p><?php echo e($car->trim ?: $car->attention_grabber); ?></p>
            <dl>
                <div><dt>Year</dt><dd><?php echo e($car->year ?: '—'); ?></dd></div>
                <div><dt>Mileage</dt><dd><span class="stock-miles-full"><?php echo e($milesFull); ?></span><span class="stock-miles-short"><?php echo e($milesShort); ?></span></dd></div>
                <div><dt>Gearbox</dt><dd><?php echo e($gear !== '' ? $gear : '—'); ?></dd></div>
                <div><dt>Fuel</dt><dd><?php echo e($car->fuel ?: '—'); ?></dd></div>
            </dl>
        </div>
    </div>
    <div class="stock-buy">
        <div class="stock-prices">
            <div>
                <small>Cash price</small>
                <strong><?php echo e(\App\Support\Money::gbp($price)); ?></strong>
            </div>
            <?php if($monthly): ?>
                <div>
                    <b>£<?php echo e(number_format($monthly)); ?> <span class="stock-mo">/mo</span></b>
                    <small title="Assumed 12.9% APR over 48 months with a 10% deposit. An illustration, not a finance quote.">Illustration · 10% dep</small>
                </div>
            <?php endif; ?>
        </div>
        <div class="stock-actions">
            <?php if(auth()->guard()->check()): ?>
                <a class="stock-reserve" href="<?php echo e(route('cars.show', $car->slug)); ?>#reserve">Reserve</a>
            <?php else: ?>
                <a class="stock-reserve" href="<?php echo e(route('login', ['redirect' => route('cars.show', $car->slug, false).'#reserve'])); ?>">Reserve</a>
            <?php endif; ?>
            <a class="stock-view" href="<?php echo e(route('cars.show', $car->slug)); ?>">View vehicle</a>
        </div>
    </div>
</article>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/partials/stock-card.blade.php ENDPATH**/ ?>