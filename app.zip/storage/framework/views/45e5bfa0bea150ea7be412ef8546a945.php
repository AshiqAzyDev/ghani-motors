<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>All alerts</h2>
            <p class="meta"><?php echo e($counts['alerts']); ?> unread · page <?php echo e($notifications->currentPage()); ?> of <?php echo e(max($notifications->lastPage(), 1)); ?></p>
        </div>
        <?php if($counts['alerts'] > 0): ?>
            <form method="post" action="<?php echo e(route('account.notifications.read-all')); ?>"><?php echo csrf_field(); ?><button class="btn smallbtn ghost" type="submit">Mark all read</button></form>
        <?php endif; ?>
    </div>
    <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="account-alert <?php if(!$note->read_at): ?> is-unread <?php endif; ?>">
            <div>
                <b><?php echo e($note->title); ?></b>
                <?php if($note->body): ?><p class="meta"><?php echo e($note->body); ?></p><?php endif; ?>
                <small><?php echo e($note->created_at?->diffForHumans()); ?></small>
            </div>
            <a class="btn smallbtn ghost" href="<?php echo e(route('account.notifications.read', $note)); ?>">Open</a>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="account-empty"><p>No alerts yet. Booking and invoice updates will show here.</p></div>
    <?php endif; ?>
    <div class="account-pager"><?php echo e($notifications->links()); ?></div>
</section>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account/alerts.blade.php ENDPATH**/ ?>