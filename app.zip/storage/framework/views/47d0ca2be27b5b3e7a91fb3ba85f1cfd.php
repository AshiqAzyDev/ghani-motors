<?php $__env->startSection('title', 'Your account'); ?>
<?php $__env->startSection('content'); ?>
<?php
    $firstName = \Illuminate\Support\Str::of($customer->name)->before(' ')->toString() ?: $customer->name;
    $nav = [
        'overview' => ['label' => 'Overview', 'count' => null],
        'saved' => ['label' => 'Saved cars', 'count' => $counts['saved']],
        'bookings' => ['label' => 'Bookings', 'count' => $counts['bookings']],
        'enquiries' => ['label' => 'Enquiries', 'count' => $counts['enquiries']],
        'invoices' => ['label' => 'Invoices', 'count' => $counts['invoices']],
        'alerts' => ['label' => 'Alerts', 'count' => $counts['alerts'], 'hot' => true],
        'profile' => ['label' => 'Profile', 'count' => null],
    ];
    $titles = [
        'overview' => 'Overview',
        'saved' => 'Saved cars',
        'bookings' => 'Bookings',
        'enquiries' => 'Enquiries',
        'invoices' => 'Invoices & purchases',
        'alerts' => 'Alerts',
        'profile' => 'Profile & security',
    ];
?>
<section class="account-shell">
    <aside class="account-sidebar">
        <div class="account-sidebar-head">
            <p class="eyebrow">Your account</p>
            <strong><?php echo e($customer->name); ?></strong>
            <small><?php echo e($customer->email); ?></small>
        </div>
        <nav class="account-side-nav" aria-label="Account navigation">
            <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($key === 'overview' ? route('account') : route('account', $key)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => $section === $key]); ?>">
                    <span><?php echo e($item['label']); ?></span>
                    <?php if(! is_null($item['count'])): ?>
                        <em class="<?php echo \Illuminate\Support\Arr::toCssClasses(['is-hot' => !empty($item['hot']) && $item['count'] > 0]); ?>"><?php echo e($item['count']); ?></em>
                    <?php endif; ?>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
        <div class="account-sidebar-foot">
            <a class="btn smallbtn" href="<?php echo e(route('stock')); ?>">Browse stock</a>
        </div>
    </aside>

    <div class="account-main">
        <header class="account-main-head">
            <div>
                <p class="eyebrow">Ghani Motors</p>
                <h1><?php echo e($titles[$section] ?? 'Account'); ?></h1>
            </div>
            <?php if($section === 'overview'): ?>
                <p class="meta">Hello, <?php echo e($firstName); ?> — here’s a snapshot of your activity.</p>
            <?php elseif($section === 'saved'): ?>
                <p class="meta"><?php echo e($counts['saved']); ?> saved car<?php echo e($counts['saved'] === 1 ? '' : 's'); ?>. Sold or hidden cars stay listed so you can remove them.</p>
            <?php elseif($section === 'bookings'): ?>
                <p class="meta"><?php echo e($counts['open_bookings']); ?> open · <?php echo e($counts['bookings']); ?> total</p>
            <?php elseif($section === 'alerts'): ?>
                <p class="meta"><?php echo e($counts['alerts']); ?> unread</p>
            <?php endif; ?>
        </header>

        <?php echo $__env->make('site.account.'.$section, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account.blade.php ENDPATH**/ ?>