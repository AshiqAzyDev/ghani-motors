<?php $__env->startSection('title', 'Overview'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if(auth('staff')->user()->isAdmin()): ?>
        <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.settings')); ?>">Settings</a>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('vehicles.edit_manual')): ?>
        <a class="btn smallbtn" href="<?php echo e(route('dealer.vehicles.create')); ?>">Add manual car</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="welcome dash-welcome">
    <div>
        <h2>Welcome back<?php echo e(auth('staff')->user()->name ? ', '.auth('staff')->user()->name : ''); ?></h2>
        <p class="page-note" style="margin:0;">Stock, leads, bookings and sales at a glance.</p>
    </div>
    <?php if(auth('staff')->user()->isAdmin()): ?>
        <div class="dash-sync">
            <span class="at-pill <?php echo e(($lastSync?->status === 'succeeded') ? 'ok' : (($lastSync?->status === 'failed') ? 'bad' : 'unknown')); ?>">
                Last sync: <?php echo e($lastSync ? $lastSync->kind.' · '.$lastSync->status : 'none yet'); ?>

            </span>
        </div>
    <?php endif; ?>
</div>

<div class="metrics dash-metrics">
    <?php if(auth('staff')->user()->can('vehicles.view')): ?>
        <div class="metric"><span>Available stock</span><strong><?php echo e($counts['available'] ?? 0); ?></strong></div>
        <div class="metric"><span>Reserved</span><strong><?php echo e($counts['reserved'] ?? 0); ?></strong></div>
        <div class="metric"><span>Stock value</span><strong><?php echo e(\App\Support\Money::gbp($stockValue)); ?></strong></div>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('leads.view')): ?>
        <div class="metric"><span>New leads</span><strong><?php echo e($newLeads); ?></strong></div>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('bookings.view')): ?>
        <div class="metric"><span>Open bookings</span><strong><?php echo e($openBookings); ?></strong></div>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('sales.view')): ?>
        <div class="metric"><span>Sales this month</span><strong><?php echo e(\App\Support\Money::gbp($salesThisMonth)); ?></strong></div>
        <div class="metric"><span>Completed sales</span><strong><?php echo e($salesCount); ?></strong></div>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('invoices.view')): ?>
        <div class="metric"><span>Outstanding invoices</span><strong><?php echo e(\App\Support\Money::gbp($outstanding)); ?></strong></div>
    <?php endif; ?>
</div>

<?php if(
    (auth('staff')->user()->can('leads.view') && $attention['new_leads'])
    || (auth('staff')->user()->can('bookings.view') && $attention['open_bookings'])
    || (auth('staff')->user()->can('invoices.view') && $attention['outstanding'] > 0)
    || (auth('staff')->user()->isAdmin() && ($attention['failed_hooks'] || ! $attention['whatsapp_live'] || ! $attention['webhook_set']))
): ?>
    <div class="dash-alerts panel">
        <h2>Needs attention</h2>
        <ul>
            <?php if(auth('staff')->user()->can('leads.view') && $attention['new_leads']): ?>
                <li><a href="<?php echo e(route('dealer.leads', ['status' => 'new'])); ?>"><?php echo e($attention['new_leads']); ?> new lead<?php echo e($attention['new_leads'] === 1 ? '' : 's'); ?> waiting</a></li>
            <?php endif; ?>
            <?php if(auth('staff')->user()->can('bookings.view') && $attention['open_bookings']): ?>
                <li><a href="<?php echo e(route('dealer.bookings')); ?>"><?php echo e($attention['open_bookings']); ?> open booking<?php echo e($attention['open_bookings'] === 1 ? '' : 's'); ?></a></li>
            <?php endif; ?>
            <?php if(auth('staff')->user()->can('invoices.view') && $attention['outstanding'] > 0): ?>
                <li><a href="<?php echo e(route('dealer.invoices')); ?>">Outstanding invoices: <?php echo e(\App\Support\Money::gbp($attention['outstanding'])); ?></a></li>
            <?php endif; ?>
            <?php if(auth('staff')->user()->isAdmin() && $attention['failed_hooks']): ?>
                <li><a href="<?php echo e(route('dealer.settings')); ?>"><?php echo e($attention['failed_hooks']); ?> failed webhook<?php echo e($attention['failed_hooks'] === 1 ? '' : 's'); ?></a></li>
            <?php endif; ?>
            <?php if(auth('staff')->user()->isAdmin() && ! $attention['whatsapp_live']): ?>
                <li><a href="<?php echo e(route('dealer.settings')); ?>">Set a real phone number to show WhatsApp on the website</a></li>
            <?php endif; ?>
            <?php if(auth('staff')->user()->isAdmin() && ! $attention['webhook_set']): ?>
                <li><a href="<?php echo e(route('dealer.settings')); ?>">Webhook secret is not set — live Autotrader updates are blocked</a></li>
            <?php endif; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="dashboard-grid dash-charts">
    <?php if(auth('staff')->user()->can('vehicles.view')): ?>
        <section class="panel chart-panel">
            <h2>Stock by status</h2>
            <canvas id="chart-stock" height="220" aria-label="Stock status chart"></canvas>
        </section>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('leads.view')): ?>
        <section class="panel chart-panel">
            <h2>Leads · last 14 days</h2>
            <canvas id="chart-leads" height="220" aria-label="Leads chart"></canvas>
        </section>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('sales.view')): ?>
        <section class="panel chart-panel">
            <h2>Sales value · 6 months</h2>
            <canvas id="chart-sales" height="220" aria-label="Sales chart"></canvas>
        </section>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('bookings.view')): ?>
        <section class="panel chart-panel">
            <h2>Open bookings by type</h2>
            <canvas id="chart-bookings" height="220" aria-label="Bookings chart"></canvas>
        </section>
    <?php endif; ?>
</div>

<div class="dashboard-grid" style="margin-top:1rem;">
    <?php if(auth('staff')->user()->can('leads.view')): ?>
        <section class="panel">
            <div class="dsectionhead">
                <h2>Recent leads</h2>
                <a class="textlink" href="<?php echo e(route('dealer.leads')); ?>">View all</a>
            </div>
            <div class="table-scroll">
                <table class="data-table">
                    <thead><tr><th>Customer</th><th>Type</th><th>Status</th><th>When</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentLeads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="is-clickable" onclick="window.location='<?php echo e(route('dealer.leads.show', $lead)); ?>'" style="cursor:pointer;">
                                <td><a href="<?php echo e(route('dealer.leads.show', $lead)); ?>"><?php echo e($lead->customer?->name ?? '—'); ?></a></td>
                                <td><?php echo e(str_replace('_', ' ', $lead->type)); ?></td>
                                <td><span class="badge <?php echo e($lead->status); ?>"><?php echo e($lead->status); ?></span></td>
                                <td><?php echo e(optional($lead->created_at)->timezone(config('app.timezone'))->format('j M H:i')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="empty-row">No leads yet.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('bookings.view')): ?>
        <section class="panel">
            <div class="dsectionhead">
                <h2>Upcoming bookings</h2>
                <a class="textlink" href="<?php echo e(route('dealer.bookings')); ?>">View all</a>
            </div>
            <div class="table-scroll">
                <table class="data-table">
                    <thead><tr><th>Customer</th><th>Type</th><th>When</th><th>Status</th></tr></thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $upcomingBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="is-clickable" onclick="window.location='<?php echo e(route('dealer.bookings')); ?>'" style="cursor:pointer;">
                                <td>
                                    <?php if($booking->customer && auth('staff')->user()->can('customers.view')): ?>
                                        <a href="<?php echo e(route('dealer.customers.show', $booking->customer)); ?>"><?php echo e($booking->customer->name); ?></a>
                                    <?php else: ?>
                                        <?php echo e($booking->customer?->name ?? '—'); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(str_replace('_', ' ', $booking->type)); ?></td>
                                <td>
                                    <?php echo e(optional($booking->preferred_on)->format('j M Y')); ?>

                                    <?php if($booking->preferred_time): ?> · <?php echo e(\Illuminate\Support\Str::of($booking->preferred_time)->substr(0, 5)); ?><?php endif; ?>
                                </td>
                                <td><span class="badge <?php echo e($booking->status); ?>"><?php echo e($booking->status); ?></span></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="4" class="empty-row">No open bookings.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endif; ?>
</div>

<section class="panel" style="margin-top:1rem;">
    <div class="dsectionhead">
        <h2>Recent activity</h2>
        <?php if(auth('staff')->user()->can('customers.view')): ?>
            <span class="meta"><?php echo e($customersTotal); ?> customers · <?php echo e($customersMonth); ?> new this month</span>
        <?php endif; ?>
    </div>
    <div class="table-scroll">
        <table class="data-table">
            <thead>
                <tr><th class="sno">S.no</th><th>When</th><th>Activity</th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="sno"><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($row->created_at?->timezone(config('app.timezone'))->format('j M Y H:i')); ?></td>
                        <td><?php echo e($row->message); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="3" class="empty-row">No activity yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php if(auth('staff')->user()->can('vehicles.view') || auth('staff')->user()->can('leads.view') || auth('staff')->user()->can('sales.view') || auth('staff')->user()->can('bookings.view')): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.8/dist/chart.umd.min.js" defer></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    if (!window.Chart) return;
    const charts = <?php echo json_encode($charts, 15, 512) ?>;
    const teal = '#00a0d0';
    const ink = '#101616';
    const muted = ['#00a0d0', '#0b192c', '#64748b', '#94a3b8', '#25d366', '#f59e0b'];

    const stockEl = document.getElementById('chart-stock');
    if (stockEl) {
        new Chart(stockEl, {
            type: 'doughnut',
            data: {
                labels: charts.stock.labels,
                datasets: [{ data: charts.stock.values, backgroundColor: muted, borderWidth: 0 }]
            },
            options: { plugins: { legend: { position: 'bottom' } }, cutout: '58%' }
        });
    }

    const leadsEl = document.getElementById('chart-leads');
    if (leadsEl) {
        new Chart(leadsEl, {
            type: 'line',
            data: {
                labels: charts.leads.labels,
                datasets: [{
                    label: 'Leads',
                    data: charts.leads.values,
                    borderColor: teal,
                    backgroundColor: 'rgba(0,160,208,.15)',
                    fill: true,
                    tension: .35,
                    pointRadius: 3,
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });
    }

    const salesEl = document.getElementById('chart-sales');
    if (salesEl) {
        new Chart(salesEl, {
            type: 'bar',
            data: {
                labels: charts.sales.labels,
                datasets: [{
                    label: '£',
                    data: charts.sales.values,
                    backgroundColor: ink,
                    borderRadius: 6,
                }]
            },
            options: {
                plugins: { legend: { display: false } },
                scales: { y: { beginAtZero: true } }
            }
        });
    }

    const bookingsEl = document.getElementById('chart-bookings');
    if (bookingsEl) {
        new Chart(bookingsEl, {
            type: 'bar',
            data: {
                labels: charts.bookings.labels,
                datasets: [{
                    data: charts.bookings.values,
                    backgroundColor: [teal, ink, '#64748b'],
                    borderRadius: 6,
                }]
            },
            options: {
                indexAxis: 'y',
                plugins: { legend: { display: false } },
                scales: { x: { beginAtZero: true, ticks: { precision: 0 } } }
            }
        });
    }
});
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/overview.blade.php ENDPATH**/ ?>