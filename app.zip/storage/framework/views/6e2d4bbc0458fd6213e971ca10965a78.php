<?php $__env->startSection('title', 'Invoices'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if(auth('staff')->user()->can('invoices.manage')): ?>
        <a class="btn smallbtn" href="<?php echo e(route('dealer.invoices.create')); ?>">New invoice</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form method="get" class="list-bar">
    <input name="q" value="<?php echo e(request('q')); ?>" placeholder="Number, customer, car">
    <input type="date" name="from" value="<?php echo e(request('from')); ?>" aria-label="From date">
    <input type="date" name="to" value="<?php echo e(request('to')); ?>" aria-label="To date">
    <select name="status"><option value="">Any status</option><?php $__currentLoopData = ['draft','issued','part_paid','paid','void','credited']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst(str_replace('_',' ', $status))); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    <button class="btn smallbtn" type="submit">Filter</button>
</form>
<div class="panel table-scroll">
    <table class="data-table">
        <thead>
            <tr><th class="sno">S.no</th><th>Number</th><th>Customer</th><th>Scheme</th><th class="num">Total</th><th>Status</th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="sno"><?php echo e($rows->firstItem() + $loop->index); ?></td>
                    <td><a href="<?php echo e(route('dealer.invoices.show', $row)); ?>"><?php echo e($row->number); ?></a><small><?php echo e(ucfirst(str_replace('_',' ', $row->kind))); ?></small></td>
                    <td><?php echo e($row->customer?->name); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_',' ', $row->vat_scheme))); ?></td>
                    <td class="num"><?php echo e(\App\Support\Money::gbp($row->total_pence)); ?></td>
                    <td><span class="badge <?php echo e($row->status); ?>"><?php echo e(ucfirst(str_replace('_',' ', $row->status))); ?></span></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="empty-row">No invoices match this filter.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/invoices/index.blade.php ENDPATH**/ ?>