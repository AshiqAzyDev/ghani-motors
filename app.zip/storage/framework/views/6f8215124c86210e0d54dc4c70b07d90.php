<?php $__env->startSection('title', 'Leads'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if(auth('staff')->user()->can('leads.view')): ?>
        <a class="btn smallbtn" href="<?php echo e(route('dealer.export', 'leads')); ?>">Export CSV</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form method="get" class="list-bar">
    <select name="status" onchange="this.form.submit()">
        <option value="">Any status</option>
        <?php $__currentLoopData = ['new','contacted','closed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</form>
<div class="panel table-scroll">
    <table class="data-table">
        <thead>
            <tr><th class="sno">S.no</th><th>Subject</th><th>Customer</th><th>Requirements</th><th>Type</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="sno"><?php echo e($rows->firstItem() + $loop->index); ?></td>
                    <td>
                        <a href="<?php echo e(route('dealer.leads.show', $row)); ?>"><b><?php echo e($row->subject); ?></b></a>
                        <?php if($row->valuation): ?><small><?php echo e($row->valuation->registration); ?> · <?php echo e($row->valuation->mileage); ?> miles</small><?php endif; ?>
                        <?php if($row->contact_notes || $row->additional_notes): ?><small>Has notes</small><?php endif; ?>
                    </td>
                    <td><?php echo e($row->customer?->name); ?><small><?php echo e($row->customer?->phone); ?></small></td>
                    <td>
                        <?php $__empty_2 = true; $__currentLoopData = $row->requirementPairs(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                            <span class="req-pill"><?php echo e($pair['label']); ?>: <?php echo e($pair['value']); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                            —
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(ucfirst(str_replace('_',' ', $row->type))); ?></td>
                    <td><span class="badge <?php echo e($row->status); ?>"><?php echo e(ucfirst($row->status)); ?></span></td>
                    <td class="row-actions"><a class="rowbtn" href="<?php echo e(route('dealer.leads.show', $row)); ?>">Open</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="empty-row">No leads match this filter.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/leads.blade.php ENDPATH**/ ?>