<div class="stock-countbar">
    <b><?php echo e(number_format($cars->total())); ?> <?php echo e(\Illuminate\Support\Str::plural('car', $cars->total())); ?> in stock</b>
    <span>In stock</span>
</div>
<?php if($cars->isEmpty()): ?>
    <div class="stock-empty">
        <h3>No cars match that search.</h3>
        <p>Try another make, price or registration.</p>
    </div>
<?php else: ?>
    <div class="stock-grid">
        <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo $__env->make('partials.stock-card', ['car' => $car], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php endif; ?>
<?php if($cars->hasPages()): ?>
    <nav class="stock-pager" aria-label="Pagination">
        <p>Showing <b><?php echo e($cars->firstItem()); ?>–<?php echo e($cars->lastItem()); ?></b> of <b><?php echo e($cars->total()); ?></b> cars in <?php echo e($dealer->city ?? 'Dagenham'); ?></p>
        <div>
            <?php if($cars->onFirstPage()): ?>
                <span class="stock-page-step is-disabled">Prev</span>
            <?php else: ?>
                <a class="stock-page-step" href="<?php echo e($cars->previousPageUrl()); ?>">Prev</a>
            <?php endif; ?>
            <?php $__currentLoopData = $cars->getUrlRange(max(1, $cars->currentPage() - 2), min($cars->lastPage(), $cars->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page === $cars->currentPage()): ?>
                    <span class="is-current" aria-current="page"><?php echo e($page); ?></span>
                <?php else: ?>
                    <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($cars->hasMorePages()): ?>
                <a class="stock-page-step" href="<?php echo e($cars->nextPageUrl()); ?>">Next</a>
            <?php else: ?>
                <span class="stock-page-step is-disabled">Next</span>
            <?php endif; ?>
        </div>
    </nav>
<?php endif; ?>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/partials/stock-results.blade.php ENDPATH**/ ?>