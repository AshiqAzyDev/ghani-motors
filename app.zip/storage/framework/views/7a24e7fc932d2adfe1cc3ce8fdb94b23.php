<?php
    $dealer = $siteDealer ?? \App\Models\Dealer::current();
    $place = $dealer->showroomAddress();
    $query = rawurlencode($place);
?>
<section class="map">
    <iframe title="Ghani Motors on Google Maps" loading="lazy" referrerpolicy="no-referrer-when-downgrade" src="<?php echo e($dealer->mapsEmbedUrl()); ?>"></iframe>
    <div class="body">
        <p style="margin:0;"><?php echo e($place); ?></p>
        <a class="btn" href="<?php echo e($dealer->mapsDirectionsUrl()); ?>" target="_blank" rel="noopener">Get directions</a>
    </div>
</section>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/partials/map.blade.php ENDPATH**/ ?>