<?php $__env->startSection('title', 'Sell or part-exchange'); ?>
<?php $__env->startSection('content'); ?>
<section class="flowlayout">
    <div>
        <div class="crumb"><a href="<?php echo e(route('home')); ?>">Home</a> / Sell your car</div>
        <div class="eyebrow">A fresh start, without the fuss</div>
        <h1>Ready to move on?<br>Let’s talk about<br><span style="color:var(--teal)">your car.</span></h1>
        <p class="sub">Sell your car or put its value towards your next one. Start with a few simple details.</p>
        <ol class="flowlist">
            <li><i>1</i><div>Tell us about your car<small>Registration, mileage and a few key details.</small></div></li>
            <li><i>2</i><div>Help us get the full picture<small>Condition, history and optional photos.</small></div></li>
            <li><i>3</i><div>Let’s arrange the next step<small>Our team will review your details and discuss a valuation.</small></div></li>
        </ol>
        <div class="hint">A valuation enquiry is free and comes with no obligation. Any offer is subject to inspection and vehicle checks. Registration is entered by hand.</div>
    </div>
    <div class="panel">
        <div class="steps"><div class="step on"></div><div class="step"></div><div class="step"></div></div>
        <form method="post" action="<?php echo e(route('sell.store')); ?>" enctype="multipart/form-data" data-steps>
            <?php echo csrf_field(); ?>
            <fieldset class="sell-step active">
                <div class="eyebrow">Step 1 of 3</div>
                <h2>Your car details</h2>
                <p>Let’s start with the essentials.</p>
                <div class="formgrid">
                    <label class="full">Vehicle registration<input class="reg" name="registration" required maxlength="9" value="<?php echo e(old('registration')); ?>" placeholder="AB12 CDE"></label>
                    <label>Current mileage<input type="number" name="mileage" required min="0" value="<?php echo e(old('mileage')); ?>"></label>
                    <label>Make<input name="make" required value="<?php echo e(old('make')); ?>"></label>
                    <label>Model<input name="model" required value="<?php echo e(old('model')); ?>"></label>
                    <label>Year<input type="number" name="year" required value="<?php echo e(old('year')); ?>"></label>
                    <label>Fuel<input name="fuel" required value="<?php echo e(old('fuel')); ?>"></label>
                    <label class="full">Transmission<input name="transmission" required value="<?php echo e(old('transmission')); ?>"></label>
                </div>
                <div class="formactions"><span></span><button class="btn" type="button" data-next>Continue</button></div>
            </fieldset>
            <fieldset class="sell-step">
                <div class="eyebrow">Step 2 of 3</div>
                <h2>A little more about your car</h2>
                <p>These details help the team assess your vehicle.</p>
                <div class="formgrid">
                    <label>I want to
                        <select name="intent">
                            <option value="sell" <?php if(old('intent') === 'sell'): echo 'selected'; endif; ?>>Sell</option>
                            <option value="part_exchange" <?php if(old('intent') === 'part_exchange'): echo 'selected'; endif; ?>>Part-exchange</option>
                        </select>
                    </label>
                    <label>Condition
                        <select name="condition"><?php $__currentLoopData = ['excellent','good','fair','needs_attention']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($option); ?>" <?php if(old('condition') === $option): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', $option)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                    </label>
                    <label>Service history
                        <select name="service_history"><?php $__currentLoopData = ['full','partial','none','not_sure']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($option); ?>" <?php if(old('service_history') === $option): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', $option)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                    </label>
                    <label>Outstanding finance
                        <select name="outstanding_finance"><?php $__currentLoopData = ['no','yes','not_sure']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($option); ?>" <?php if(old('outstanding_finance') === $option): echo 'selected'; endif; ?>><?php echo e(str_replace('_', ' ', $option)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                    </label>
                    <label>MOT expiry<input type="date" name="mot_expiry" value="<?php echo e(old('mot_expiry')); ?>"></label>
                    <label class="full">Notes<textarea name="notes"><?php echo e(old('notes')); ?></textarea></label>
                    <label class="full">Photos<input type="file" name="photos[]" accept="image/*" multiple></label>
                </div>
                <div class="formactions"><button class="btn outline" type="button" data-back>Back</button><button class="btn" type="button" data-next>Continue</button></div>
            </fieldset>
            <fieldset class="sell-step">
                <div class="eyebrow">Step 3 of 3</div>
                <h2>How can we reach you?</h2>
                <p>We’ll use these details to discuss your valuation.</p>
                <div class="formgrid">
                    <?php echo $__env->make('partials.contact-fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <label>Postcode<input name="postcode" required value="<?php echo e(old('postcode')); ?>"></label>
                    <label>Preferred contact
                        <select name="preferred_contact"><option value="phone">Phone</option><option value="email">Email</option></select>
                    </label>
                </div>
                <div class="formactions"><button class="btn outline" type="button" data-back>Back</button><button class="btn" type="submit">Send details</button></div>
            </fieldset>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/site/sell.blade.php ENDPATH**/ ?>