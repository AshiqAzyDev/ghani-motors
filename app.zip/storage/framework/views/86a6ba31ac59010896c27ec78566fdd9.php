<?php if($paginator->hasPages()): ?>
    <nav class="pager">
        <?php if($paginator->onFirstPage()): ?>
            <span>Previous</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>">Previous</a>
        <?php endif; ?>
        <span>Page <?php echo e($paginator->currentPage()); ?> of <?php echo e($paginator->lastPage()); ?></span>
        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>">Next</a>
        <?php else: ?>
            <span>Next</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/pagination/plain.blade.php ENDPATH**/ ?>