<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if(auth('staff')->user()->can('customers.view')): ?>
        <a class="btn smallbtn" href="<?php echo e(route('dealer.export', 'customers')); ?>">Export CSV</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form method="get" class="list-bar"><input name="q" value="<?php echo e(request('q')); ?>" placeholder="Name, email, phone"><button class="btn smallbtn" type="submit">Search</button></form>
<?php if(auth('staff')->user()->can('customers.manage')): ?>
<form class="panel" method="post" action="<?php echo e(route('dealer.customers.store')); ?>" style="margin:1rem 0;">
    <?php echo csrf_field(); ?>
    <div class="row">
        <input name="name" placeholder="Name" required>
        <input type="email" name="email" placeholder="Email" required>
        <input name="phone" placeholder="Phone" required>
        <input name="postcode" placeholder="Postcode">
        <select name="source"><?php $__currentLoopData = ['showroom','phone','website_enquiry','finance_enquiry','sell_your_car','other']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $source): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($source); ?>"><?php echo e(str_replace('_',' ', $source)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <label>Notes</label><textarea name="notes"></textarea>
    <button class="btn" type="submit">Add customer</button>
</form>
<?php endif; ?>
<div class="panel table-scroll">
    <table class="data-table">
        <thead>
            <tr><th class="sno">S.no</th><th>Name</th><th>Email</th><th>Phone</th><th>Source</th><th></th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="sno"><?php echo e($rows->firstItem() + $loop->index); ?></td>
                    <td><a href="<?php echo e(route('dealer.customers.show', $row)); ?>"><?php echo e($row->name); ?></a></td>
                    <td><?php echo e($row->email); ?></td>
                    <td><?php echo e($row->phone); ?></td>
                    <td><?php echo e(ucfirst(str_replace('_',' ', $row->source))); ?></td>
                    <td class="row-actions"><a class="rowbtn" href="<?php echo e(route('dealer.customers.show', $row)); ?>">Open</a></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="empty-row">No customers match this search.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/customers.blade.php ENDPATH**/ ?>