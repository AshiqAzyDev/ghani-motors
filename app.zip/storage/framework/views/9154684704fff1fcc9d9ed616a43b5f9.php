<?php
    $customer = $invoice->customer_snapshot ?? [];
    $vehicle = $invoice->vehicle_snapshot ?? [];
    $customerName = trim((string) ($customer['name'] ?? '')) ?: 'Customer';
    $paidPence = (int) $invoice->payments->sum('amount_pence');
    $balancePence = (int) $invoice->total_pence - $paidPence;
    $isPaidInFull = $invoice->status === 'paid'
        || ($balancePence <= 0 && $paidPence > 0 && (int) $invoice->total_pence > 0);
    $statusLabel = ucfirst(str_replace('_', ' ', $invoice->status));
    $kindLabel = $invoice->kind === 'credit_note' ? 'Credit Note' : 'Sales Invoice & Receipt';
    $schemeLabel = ucfirst(str_replace('_', ' ', $invoice->vat_scheme));
    $issueDate = optional($invoice->issued_at ?? $invoice->created_at)->format('j M Y');
    $signDate = optional($invoice->issued_at ?? $invoice->created_at)->format('d/m/Y');
    $dealerName = $dealer->displayName();
    $authorisedName = $invoice->creator?->name ?: $dealerName;
    $authorisedRole = $invoice->creator
        ? ucfirst((string) $invoice->creator->role).' · '.$dealerName
        : 'Authorized representative · '.$dealerName;
    $lastPayment = $invoice->payments->sortByDesc('id')->first();
?>
<article class="inv-sheet">
    <div class="inv-brand">
        <div class="inv-brand-left">
            <p class="inv-wordmark">GHANI <span>MOTORS</span></p>
            <div class="inv-badges">
                <span class="inv-badge-aa">AA Approved Dealer</span>
                <span class="inv-badge-muted"><?php echo e($dealer->displayTagline()); ?></span>
            </div>
            <div class="inv-dealer-meta">
                <p class="inv-dealer-name"><?php echo e($dealerName); ?></p>
                <p><?php echo e($dealer->showroomAddress()); ?></p>
                <p>
                    <?php if($dealer->phone): ?>Phone: <?php echo e($dealer->phone); ?><?php endif; ?>
                    <?php if($dealer->phone && $dealer->publicEmail()): ?> · <?php endif; ?>
                    <?php if($dealer->publicEmail()): ?><?php echo e($dealer->publicEmail()); ?><?php endif; ?>
                </p>
            </div>
        </div>
        <div class="inv-brand-right">
            <span class="inv-kind"><?php echo e($kindLabel); ?></span>
            <p class="inv-number">#<?php echo e($invoice->number); ?></p>
            <p class="inv-issue">Issue Date: <strong><?php echo e($issueDate ?: '—'); ?></strong></p>
            <?php if($isPaidInFull): ?>
                <div class="inv-stamp inv-stamp-paid">
                    <strong>Paid in full</strong>
                    <?php if($lastPayment): ?>
                        <span><?php echo e(optional($lastPayment->received_on)->format('j M Y')); ?><?php if($lastPayment->reference): ?> · Ref: <?php echo e($lastPayment->reference); ?><?php endif; ?></span>
                    <?php else: ?>
                        <span><?php echo e($statusLabel); ?></span>
                    <?php endif; ?>
                </div>
            <?php else: ?>
                <div class="inv-stamp inv-stamp-status <?php echo e($invoice->status); ?>">
                    <strong><?php echo e($statusLabel); ?></strong>
                    <?php if($balancePence > 0): ?>
                        <span>Balance <?php echo e(\App\Support\Money::gbp($balancePence)); ?></span>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <section class="inv-parties" aria-label="Customer and vehicle information">
        <div class="inv-card">
            <div class="inv-card-head">
                <h2>Invoice To (Customer)</h2>
            </div>
            <p class="inv-card-title"><?php echo e($customerName); ?></p>
            <div class="inv-card-body">
                <?php if(! empty($customer['address'])): ?>
                    <p><?php echo e($customer['address']); ?></p>
                <?php endif; ?>
                <?php if(! empty($customer['postcode'])): ?>
                    <p><strong><?php echo e($customer['postcode']); ?></strong></p>
                <?php endif; ?>
                <p class="inv-muted">United Kingdom</p>
            </div>
            <div class="inv-contact">
                <?php if(! empty($customer['email'])): ?>
                    <p><?php echo e($customer['email']); ?></p>
                <?php endif; ?>
                <?php if(! empty($customer['phone'])): ?>
                    <p><?php echo e($customer['phone']); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="inv-card">
            <div class="inv-card-head">
                <h2>Vehicle Specification</h2>
                <?php if(! empty($vehicle['registration'])): ?>
                    <span class="inv-plate" aria-label="Registration">
                        <span class="inv-plate-gb">GB</span>
                        <?php echo e($vehicle['registration']); ?>

                    </span>
                <?php endif; ?>
            </div>
            <p class="inv-card-title"><?php echo e($vehicle['label'] ?? '—'); ?></p>
            <div class="inv-vehicle-grid">
                <div>
                    <span class="inv-label">Vehicle</span>
                    <span><?php echo e($vehicle['label'] ?? '—'); ?></span>
                </div>
                <div>
                    <span class="inv-label">Registration</span>
                    <span><?php echo e($vehicle['registration'] ?? '—'); ?></span>
                </div>
                <div>
                    <span class="inv-label">VAT scheme</span>
                    <span class="inv-scheme"><?php echo e($schemeLabel); ?></span>
                </div>
                <?php if(! empty($vehicle['vat_status'])): ?>
                    <div>
                        <span class="inv-label">VAT status</span>
                        <span><?php echo e($vehicle['vat_status']); ?></span>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>

    <section class="inv-lines" aria-label="Itemized charges">
        <table>
            <thead>
                <tr>
                    <th class="sno">S.no</th>
                    <th>Item &amp; Description</th>
                    <th class="num">Net</th>
                    <th class="num">VAT</th>
                    <th class="num">Total</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $invoice->lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="sno"><?php echo e($loop->iteration); ?></td>
                        <td>
                            <strong><?php echo e($line->description); ?></strong>
                            <small><?php echo e(ucfirst(str_replace('_', ' ', $line->line_type))); ?><?php if($line->quantity && (float) $line->quantity !== 1.0): ?> · Qty <?php echo e($line->quantity); ?><?php endif; ?></small>
                        </td>
                        <td class="num"><?php echo e(\App\Support\Money::gbp($line->unit_net_pence)); ?></td>
                        <td class="num">
                            <?php echo e(\App\Support\Money::gbp($line->vat_pence)); ?>
                            <?php if((int) $line->vat_rate_bps > 0): ?>
                                <small><?php echo e(number_format($line->vat_rate_bps / 100, 0)); ?>%</small>
                            <?php elseif($invoice->vat_scheme === 'margin'): ?>
                                <small>0% margin</small>
                            <?php endif; ?>
                        </td>
                        <td class="num"><strong><?php echo e(\App\Support\Money::gbp($line->line_total_pence)); ?></strong></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="empty-row">No line items.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>

    <section class="inv-summary-grid">
        <div class="inv-summary-left">
            <div class="inv-notice <?php echo e($invoice->vat_scheme === 'margin' ? 'is-margin' : ''); ?>">
                <?php if($invoice->vat_scheme === 'margin'): ?>
                    <p class="inv-notice-title">VAT Margin Scheme Disclosure</p>
                    <p><strong>Customer note:</strong> Second-hand vehicles — VAT margin scheme applied. No VAT is reclaimable on this vehicle pursuant to Section 50A of the VAT Act 1994. The buyer cannot claim any input tax on this purchase.</p>
                <?php elseif($invoice->vat_scheme === 'standard'): ?>
                    <p class="inv-notice-title">VAT Notice</p>
                    <p>Standard VAT charged at <?php echo e(number_format($invoice->vat_rate_bps / 100, 2)); ?>% where shown on line items.</p>
                <?php elseif($invoice->vat_scheme === 'exempt'): ?>
                    <p class="inv-notice-title">VAT Notice</p>
                    <p>This supply is treated as VAT exempt.</p>
                <?php else: ?>
                    <p class="inv-notice-title">VAT Notice</p>
                    <p>This supply is zero-rated for VAT.</p>
                <?php endif; ?>
            </div>

            <div class="inv-payments">
                <p class="inv-notice-title">Payment Details &amp; Settlement Log</p>
                <?php $__empty_1 = true; $__currentLoopData = $invoice->payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="inv-pay-row">
                        <span><?php echo e(optional($payment->received_on)->format('j M Y')); ?> · <?php echo e(ucfirst(str_replace('_', ' ', $payment->method))); ?></span>
                        <strong><?php echo e(\App\Support\Money::gbp($payment->amount_pence)); ?></strong>
                    </div>
                    <?php if($payment->reference): ?>
                        <div class="inv-pay-ref">Ref: <?php echo e($payment->reference); ?></div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="inv-muted">No payments recorded yet.</p>
                <?php endif; ?>
            </div>
        </div>

        <div class="inv-totals">
            <h3>Financial Summary</h3>
            <div class="inv-total-row"><span>Net Amount</span><strong><?php echo e(\App\Support\Money::gbp($invoice->net_pence)); ?></strong></div>
            <div class="inv-total-row"><span>VAT (<?php echo e($schemeLabel); ?>)</span><strong><?php echo e(\App\Support\Money::gbp($invoice->vat_pence)); ?></strong></div>
            <div class="inv-total-row inv-total-strong"><span>Total Invoice Amount</span><strong><?php echo e(\App\Support\Money::gbp($invoice->total_pence)); ?></strong></div>
            <?php if($paidPence > 0): ?>
                <div class="inv-received">
                    <div class="inv-total-row"><span>Payment Received</span><strong>- <?php echo e(\App\Support\Money::gbp($paidPence)); ?></strong></div>
                </div>
            <?php endif; ?>
            <div class="inv-balance">
                <span>Balance Due</span>
                <strong class="<?php echo e($balancePence <= 0 ? 'is-clear' : 'is-due'); ?>"><?php echo e(\App\Support\Money::gbp(max(0, $balancePence))); ?></strong>
            </div>
        </div>
    </section>

    <section class="inv-signs" aria-label="Signatures">
        <div class="inv-sign-block">
            <p class="inv-sign-label">For <?php echo e($dealerName); ?></p>
            <div class="inv-sign-line">
                <span class="inv-sign-name"><?php echo e($authorisedName); ?></span>
            </div>
            <div class="inv-sign-meta">
                <span>
                    <strong>Authorized Signatory</strong><br>
                    <?php echo e($authorisedRole); ?>

                </span>
                <span>Date: <?php echo e($signDate ?: '—'); ?></span>
            </div>
        </div>
        <div class="inv-sign-block">
            <p class="inv-sign-label">Customer Handover Acceptance</p>
            <div class="inv-sign-line">
                <span class="inv-sign-name"><?php echo e($customerName); ?></span>
            </div>
            <div class="inv-sign-meta">
                <span>
                    <strong>Customer acceptance</strong><br>
                    <?php echo e($customerName); ?>

                    <?php if(! empty($customer['postcode'])): ?>
                        · <?php echo e($customer['postcode']); ?>

                    <?php endif; ?>
                </span>
                <span>Date: <?php echo e($signDate ?: '—'); ?></span>
            </div>
        </div>
    </section>

    <div class="inv-footer">
        <p><strong>Thank you for your business with <?php echo e($dealerName); ?>.</strong></p>
        <p>Registered showroom: <?php echo e($dealer->showroomAddress()); ?></p>
        <p>This document serves as your official sales receipt and proof of purchase.</p>
    </div>
</article>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/invoices/_document.blade.php ENDPATH**/ ?>