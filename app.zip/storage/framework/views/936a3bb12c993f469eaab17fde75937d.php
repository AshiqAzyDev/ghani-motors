<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Log in | <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?></title>
    <meta name="description" content="Log in to your <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?> account to save cars and manage enquiries.">
    <?php if($siteDealer?->faviconUrl()): ?>
        <link rel="icon" href="<?php echo e($siteDealer->faviconUrl()); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/site-fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/upgrades.min.css')); ?>">
</head>
<body class="auth-body customer-auth" data-saved="<?php echo e(implode(',', session('saved_vehicle_ids', []))); ?>">
<main class="auth-shell">
    <aside class="auth-aside">
        <a class="auth-brand" href="<?php echo e(route('home')); ?>">
            <?php if($siteDealer?->logoUrl()): ?>
                <img class="brand-logo" src="<?php echo e($siteDealer->logoUrl()); ?>" alt="<?php echo e($siteDealer->displayName()); ?>">
            <?php else: ?>
                <b>GHANI <span>MOTORS</span></b>
                <small><?php echo e($siteDealer?->displayTagline() ?? 'Quality used cars'); ?></small>
            <?php endif; ?>
        </a>
        <p class="auth-kicker">Customer account</p>
        <h1>Save cars. Pick up where you left off.</h1>
        <p>Log in to keep favourites, follow up on enquiries and come back to the cars that caught your eye.</p>
        <ul class="auth-points">
            <li>Save cars from the forecourt</li>
            <li>Return to your shortlist any time</li>
            <li>AA Approved Dealer in Dagenham</li>
        </ul>
        <?php echo $__env->make('partials.aa-badge', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <a class="auth-back" href="<?php echo e(route('stock')); ?>">← Back to stock</a>
    </aside>
    <section class="auth-card">
        <form method="post" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <h2>Welcome back</h2>
            <p class="meta">Use the email and password for your Ghani Motors account.</p>
            <?php if(session('status')): ?>
                <div class="flash"><?php echo e(session('status')); ?></div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="errors"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>
            <input type="hidden" name="saved_ids" value="">
            <label for="email">Email</label>
            <input id="email" type="email" name="email" required autocomplete="username" value="<?php echo e(old('email')); ?>">
            <?php echo $__env->make('partials.password-field', ['id' => 'password'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="auth-links">
                <a href="<?php echo e(route('password.request')); ?>">Forgot password?</a>
            </div>
            <button class="btn" type="submit">Log in</button>
            <p class="auth-foot">New here? <a href="<?php echo e(route('register')); ?>">Create an account</a></p>
        </form>
    </section>
</main>
<script src="<?php echo e(asset('js/site.min.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/auth/login.blade.php ENDPATH**/ ?>