<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>All saved cars</h2>
            <p class="meta">Page <?php echo e($saved->currentPage()); ?> of <?php echo e(max($saved->lastPage(), 1)); ?></p>
        </div>
        <a class="btn smallbtn" href="<?php echo e(route('stock')); ?>">Browse stock</a>
    </div>
    <?php if($saved->isEmpty()): ?>
        <div class="account-empty">
            <p>You haven’t saved a car yet.</p>
            <a class="btn" href="<?php echo e(route('stock')); ?>">Find cars in stock</a>
        </div>
    <?php else: ?>
        <div class="account-saved-grid">
            <?php $__currentLoopData = $saved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site.account.partials.saved-card', ['car' => $car], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="account-pager"><?php echo e($saved->links()); ?></div>
    <?php endif; ?>
</section>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account/saved.blade.php ENDPATH**/ ?>