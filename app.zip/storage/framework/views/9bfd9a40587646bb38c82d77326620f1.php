<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('title', 'Used cars in Dagenham'); ?> | <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('description', ($siteDealer?->displayName() ?? 'Ghani Motors').', used cars on '.($siteDealer?->showroomAddress() ?? 'Rainham Road South, Dagenham').'.'); ?>">
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">
    <meta property="og:type" content="website">
    <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'Used cars'); ?> | <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?>">
    <meta property="og:description" content="<?php echo $__env->yieldContent('description', ($siteDealer?->displayName() ?? 'Ghani Motors').', used cars on '.($siteDealer?->showroomAddress() ?? 'Rainham Road South, Dagenham').'.'); ?>">
    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:image" content="<?php echo $__env->yieldContent('og_image', $siteDealer?->logoUrl() ?: asset('images/ghani-mail-logo.png')); ?>">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $__env->yieldContent('title', 'Used cars'); ?> | <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?>">
    <meta name="twitter:description" content="<?php echo $__env->yieldContent('description', ($siteDealer?->displayName() ?? 'Ghani Motors').', used cars on '.($siteDealer?->showroomAddress() ?? 'Rainham Road South, Dagenham').'.'); ?>">
    <meta name="twitter:image" content="<?php echo $__env->yieldContent('og_image', $siteDealer?->logoUrl() ?: asset('images/ghani-mail-logo.png')); ?>">
    <?php if($siteDealer?->faviconUrl()): ?>
        <link rel="icon" href="<?php echo e($siteDealer->faviconUrl()); ?>">
    <?php endif; ?>
    <?php echo $__env->yieldPushContent('head'); ?>
    <link rel="preload" as="font" type="font/woff2" href="<?php echo e(asset('fonts/dm-sans-rP2Yp2ywxg089UriI5-g4vlH9VoD8Cmcqbu0-K4.woff2')); ?>" crossorigin>
    <link rel="preload" as="font" type="font/woff2" href="<?php echo e(asset('fonts/manrope-xn7gYHE41ni1AdIRggexSg.woff2')); ?>" crossorigin>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/site-fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/upgrades.min.css')); ?>">
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body class="public-site" data-saved="<?php echo e(implode(',', auth()->check() ? auth()->user()->savedVehicles()->pluck('vehicle_id')->all() : session('saved_vehicle_ids', []))); ?>">
    <header>
        <a class="brand" href="<?php echo e(route('home')); ?>">
            <?php if($siteDealer?->logoUrl()): ?>
                <img class="brand-logo" src="<?php echo e($siteDealer->logoUrl()); ?>" alt="<?php echo e($siteDealer->displayName()); ?>">
            <?php else: ?>
                <b>GHANI<span>MOTORS</span></b><small><?php echo e($siteDealer?->displayTagline() ?? 'QUALITY USED CARS'); ?></small>
            <?php endif; ?>
        </a>
        <nav id="main-nav" aria-label="Main navigation" data-menu>
            <a href="<?php echo e(route('stock')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('stock')]); ?>">Find a car</a>
            <a href="<?php echo e(route('sell')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('sell')]); ?>">Sell your car</a>
            <a href="<?php echo e(route('finance')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('finance')]); ?>">Car finance</a>
            <a href="<?php echo e(route('about')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs('about')]); ?>">About us</a>
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('account')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['nav-account', 'active' => request()->routeIs('account') || request()->routeIs('account.*')]); ?>">My account</a>
                <form class="nav-logout" method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Log out</button></form>
            <?php else: ?>
                
                <a class="nav-login" href="<?php echo e(route('login')); ?>">Log in</a>
            <?php endif; ?>
        </nav>
        <?php echo $__env->make('partials.aa-badge', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php if($call = $siteDealer?->whatsappNumber()): ?>
            <a class="call call-phone" href="tel:+<?php echo e($call); ?>"><?php echo e($siteDealer->phone); ?></a>
        <?php elseif($siteDealer?->publicEmail()): ?>
            <a class="call call-phone" href="mailto:<?php echo e($siteDealer->publicEmail()); ?>"><?php echo e($siteDealer->publicEmail()); ?></a>
        <?php endif; ?>
        <?php if(auth()->guard()->check()): ?>
            <a class="call call-account" href="<?php echo e(route('account')); ?>">Dashboard</a>
            <form class="call-logout" method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="call call-logout-btn" type="submit">Log out</button></form>
        <?php else: ?>
            <a class="call call-login" href="<?php echo e(route('login')); ?>">Log in</a>
        <?php endif; ?>
        <button class="mobile-menu" type="button" data-menu-button aria-label="Toggle menu" aria-expanded="false" aria-controls="main-nav">☰</button>
    </header>
    <main>
        <?php if(session('status')): ?>
            <p class="flash"><?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="errors"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
        <?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <footer>
        <div class="brand">
            <?php if($siteDealer?->logoUrl()): ?>
                <img class="brand-logo brand-logo-footer" src="<?php echo e($siteDealer->logoUrl()); ?>" alt="<?php echo e($siteDealer->displayName()); ?>">
            <?php else: ?>
                <b>GHANI<span>MOTORS</span></b><small><?php echo e($siteDealer?->displayTagline() ?? 'QUALITY USED CARS'); ?></small>
            <?php endif; ?>
        </div>
        <p><?php echo e($siteDealer?->showroomAddress() ?? 'Rainham Road South, Dagenham RM10 8YT'); ?></p>
        <?php if($siteDealer?->opening_hours): ?><p><?php echo e($siteDealer->opening_hours); ?></p><?php endif; ?>
        <?php if($siteDealer?->publicEmail()): ?><p><a href="mailto:<?php echo e($siteDealer->publicEmail()); ?>"><?php echo e($siteDealer->publicEmail()); ?></a></p><?php endif; ?>
        <div class="footerlinks">
            <a href="<?php echo e(route('stock')); ?>">Our cars</a>
            <a href="<?php echo e(route('sell')); ?>">Sell your car</a>
            <a href="<?php echo e(route('finance')); ?>">Finance</a>
            <a href="<?php echo e(route('about')); ?>">About us</a>
            <a href="<?php echo e(route('privacy')); ?>">Privacy</a>
            <a href="<?php echo e(route('dealer.login')); ?>">Dealer workspace</a>
        </div>
        <div class="footnote">© <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?> <span>Finance subject to status. Terms apply.</span></div>
    </footer>
    <?php echo $__env->make('partials.contact-dock', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <script src="<?php echo e(asset('js/site.min.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/layouts/site.blade.php ENDPATH**/ ?>