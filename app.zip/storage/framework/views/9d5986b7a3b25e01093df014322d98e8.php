<?php $__env->startSection('title', 'Bookings'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if(auth('staff')->user()->can('bookings.view')): ?>
        <a class="btn smallbtn" href="<?php echo e(route('dealer.export', 'bookings')); ?>">Export CSV</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form class="list-bar" method="get">
    <input type="hidden" name="view" value="<?php echo e($view); ?>">
    <select name="type"><option value="">Any type</option><option value="reservation" <?php if(request('type') === 'reservation'): echo 'selected'; endif; ?>>Reservation</option><option value="viewing" <?php if(request('type') === 'viewing'): echo 'selected'; endif; ?>>Viewing</option><option value="test_drive" <?php if(request('type') === 'test_drive'): echo 'selected'; endif; ?>>Test drive</option></select>
    <select name="status"><option value="">Any status</option><?php $__currentLoopData = ['held','requested','confirmed','completed','cancelled']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    <button class="btn smallbtn" type="submit">Filter</button>
    <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.bookings', array_merge(request()->except('view'), ['view' => 'list']))); ?>">List</a>
    <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.bookings', array_merge(request()->except('view'), ['view' => 'calendar']))); ?>">Calendar</a>
</form>
<?php if(auth('staff')->user()->can('bookings.manage')): ?>
<form class="panel" method="post" action="<?php echo e(route('dealer.bookings.store')); ?>" style="margin:1rem 0;" data-booking-create>
    <?php echo csrf_field(); ?>
    <div class="row">
        <select name="vehicle_id" required><option value="">Car</option><?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($car->id); ?>"><?php echo e($car->title()); ?> (<?php echo e($car->website_status); ?>)</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        <select name="customer_id" required><option value="">Customer</option><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        <select name="type" data-booking-type>
            <option value="reservation" <?php if(old('type', 'reservation') === 'reservation'): echo 'selected'; endif; ?>>Reservation</option>
            <option value="viewing" <?php if(old('type') === 'viewing'): echo 'selected'; endif; ?>>Viewing</option>
            <option value="test_drive" <?php if(old('type') === 'test_drive'): echo 'selected'; endif; ?>>Test drive</option>
        </select>
        <input type="date" name="preferred_on" required value="<?php echo e(old('preferred_on')); ?>">
        <input type="time" name="preferred_time" data-booking-time value="<?php echo e(old('preferred_time')); ?>" <?php if(old('type') && old('type') !== 'reservation'): echo 'required'; endif; ?>>
    </div>
    <p class="meta" data-booking-time-hint>Time is required for viewings and test drives.</p>
    <label>Notes</label><textarea name="notes"><?php echo e(old('notes')); ?></textarea>
    <button class="btn" type="submit">Add booking</button>
</form>
<?php endif; ?>

<?php if($view === 'calendar'): ?>
    <?php
        $start = $month->copy()->startOfMonth()->startOfWeek(Carbon\Carbon::MONDAY);
        $end = $month->copy()->endOfMonth()->endOfWeek(Carbon\Carbon::SUNDAY);
        $cursor = $start->copy();
    ?>
    <div class="list-bar" style="justify-content:space-between;">
        <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.bookings', ['view' => 'calendar', 'month' => $month->copy()->subMonth()->format('Y-m')])); ?>">← <?php echo e($month->copy()->subMonth()->format('M Y')); ?></a>
        <strong><?php echo e($month->format('F Y')); ?></strong>
        <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.bookings', ['view' => 'calendar', 'month' => $month->copy()->addMonth()->format('Y-m')])); ?>"><?php echo e($month->copy()->addMonth()->format('M Y')); ?> →</a>
    </div>
    <div class="calendar-grid" style="margin-top:1rem;">
        <?php while($cursor <= $end): ?>
            <?php ($key = $cursor->format('Y-m-d')); ?>
            <div class="calendar-cell <?php if(!$cursor->isSameMonth($month)): ?> is-muted <?php endif; ?>">
                <strong><?php echo e($cursor->day); ?></strong>
                <?php $__currentLoopData = ($calendarBookings[$key] ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="calendar-item" href="<?php echo e(route('dealer.bookings.show', $item)); ?>">
                        <?php echo e(\Illuminate\Support\Str::of($item->preferred_time)->substr(0, 5)); ?>

                        <?php echo e(ucfirst(str_replace('_', ' ', $item->type))); ?>

                        · <?php echo e($item->customer?->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php ($cursor->addDay()); ?>
        <?php endwhile; ?>
    </div>
<?php else: ?>
    <div class="panel table-scroll">
        <table class="data-table">
            <thead>
                <tr><th class="sno">S.no</th><th>When</th><th>Type</th><th>Car</th><th>Customer</th><th>Status</th><th></th></tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td class="sno"><?php echo e($rows->firstItem() + $loop->index); ?></td>
                        <td><?php echo e($row->preferred_on?->format('j M Y')); ?> <?php echo e($row->preferred_time); ?></td>
                        <td><?php echo e(ucfirst(str_replace('_', ' ', $row->type))); ?></td>
                        <td><?php echo e($row->vehicle?->title()); ?></td>
                        <td><?php if($row->customer): ?><a href="<?php echo e(route('dealer.customers.show', $row->customer)); ?>"><?php echo e($row->customer->name); ?></a><?php endif; ?></td>
                        <td><span class="badge <?php echo e($row->status); ?>"><?php echo e(ucfirst($row->status)); ?></span></td>
                        <td class="row-actions">
                            <a class="rowbtn" href="<?php echo e(route('dealer.bookings.show', $row)); ?>">View</a>
                            <?php if(auth('staff')->user()->can('bookings.manage')): ?>
                                <?php $__currentLoopData = $row->nextStatuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $next): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <form method="post" action="<?php echo e(route('dealer.bookings.status', $row)); ?>"><?php echo csrf_field(); ?><input type="hidden" name="status" value="<?php echo e($next); ?>"><button class="rowbtn" type="submit"><?php echo e(ucfirst($next)); ?></button></form>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="7" class="empty-row">No bookings match this filter.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php echo e($rows->links()); ?>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/bookings.blade.php ENDPATH**/ ?>