<?php $__env->startSection('title', $invoice->number); ?>
<?php $__env->startSection('actions'); ?>
    <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.invoices')); ?>">Back to invoices</a>
    <a class="btn smallbtn" href="<?php echo e(route('dealer.invoices.print', $invoice)); ?>" target="_blank" rel="noopener">Print</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<nav class="inv-toolbar no-print" aria-label="Invoice actions">
    <div class="inv-toolbar-left">
        <a href="<?php echo e(route('dealer.invoices')); ?>">← Back to invoices</a>
        <span class="inv-toolbar-sep" aria-hidden="true">|</span>
        <span class="inv-status-pill <?php echo e($invoice->status); ?>">
            <i aria-hidden="true"></i>
            <?php echo e(ucfirst(str_replace('_', ' ', $invoice->status))); ?>

        </span>
    </div>
    <div class="inv-toolbar-right">
        <a class="btn smallbtn" href="<?php echo e(route('dealer.invoices.print', $invoice)); ?>" target="_blank" rel="noopener">Print invoice</a>
        <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.invoices.print', $invoice)); ?>" target="_blank" rel="noopener">PDF</a>
    </div>
</nav>

<?php echo $__env->make('dealer.invoices._document', ['invoice' => $invoice, 'dealer' => $dealer], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php if(auth('staff')->user()->can('invoices.manage')): ?>
    <div class="inv-manage no-print">
        <div class="row">
            <?php if($invoice->status === 'draft'): ?>
                <form method="post" action="<?php echo e(route('dealer.invoices.issue', $invoice)); ?>"><?php echo csrf_field(); ?><button class="btn" type="submit">Issue</button></form>
            <?php endif; ?>
            <?php if(in_array($invoice->status, ['draft', 'issued']) && $invoice->payments->isEmpty()): ?>
                <form method="post" action="<?php echo e(route('dealer.invoices.void', $invoice)); ?>"><?php echo csrf_field(); ?><button class="btn danger" type="submit">Void</button></form>
            <?php endif; ?>
            <?php if($invoice->kind === 'invoice' && in_array($invoice->status, ['issued', 'part_paid', 'paid'])): ?>
                <form method="post" action="<?php echo e(route('dealer.invoices.credit', $invoice)); ?>"><?php echo csrf_field(); ?><button class="btn secondary" type="submit">Credit note</button></form>
            <?php endif; ?>
        </div>
        <?php if(in_array($invoice->status, ['issued', 'part_paid']) && $invoice->kind === 'invoice'): ?>
            <form class="panel" method="post" action="<?php echo e(route('dealer.invoices.pay', $invoice)); ?>" style="margin-top:1rem;">
                <?php echo csrf_field(); ?>
                <h2>Record a payment</h2>
                <div class="row">
                    <input name="amount" type="number" step="0.01" placeholder="Amount £" required>
                    <input type="date" name="received_on" required value="<?php echo e(now()->toDateString()); ?>">
                    <select name="method"><?php $__currentLoopData = ['bank_transfer','card','finance','cash']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($method); ?>"><?php echo e(str_replace('_',' ', $method)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                    <input name="reference" placeholder="Reference" required>
                </div>
                <button class="btn" type="submit" style="margin-top:.6rem;">Save payment</button>
            </form>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/invoices/show.blade.php ENDPATH**/ ?>