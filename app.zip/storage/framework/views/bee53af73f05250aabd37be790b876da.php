<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>Contact details</h2>
            <p class="meta">Used for bookings and showroom follow-ups.</p>
        </div>
    </div>
    <form class="account-form" method="post" action="<?php echo e(route('account.profile')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label>Name<input name="name" value="<?php echo e(old('name', $customer->name)); ?>" required></label>
        <label>Email<input value="<?php echo e($customer->email); ?>" disabled></label>
        <label>Phone<input name="phone" value="<?php echo e(old('phone', $customer->phone)); ?>" required></label>
        <div class="account-form-row">
            <label>Postcode<input name="postcode" value="<?php echo e(old('postcode', $customer->postcode)); ?>"></label>
            <label>Address<input name="address" value="<?php echo e(old('address', $customer->address)); ?>"></label>
        </div>
        <button class="btn" type="submit">Save profile</button>
    </form>
</section>

<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>Change password</h2>
            <p class="meta">Use at least 8 characters.</p>
        </div>
    </div>
    <form class="account-form" method="post" action="<?php echo e(route('account.password')); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <label>Current password<input type="password" name="current_password" required autocomplete="current-password"></label>
        <label>New password<input type="password" name="password" required minlength="8" autocomplete="new-password"></label>
        <label>Confirm password<input type="password" name="password_confirmation" required minlength="8" autocomplete="new-password"></label>
        <button class="btn ghost" type="submit">Update password</button>
    </form>
</section>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account/profile.blade.php ENDPATH**/ ?>