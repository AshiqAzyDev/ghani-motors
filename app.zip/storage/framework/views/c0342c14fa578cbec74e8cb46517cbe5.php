<?php $__env->startSection('title', 'Sales'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if(auth('staff')->user()->can('sales.view')): ?>
        <a class="btn smallbtn" href="<?php echo e(route('dealer.export', 'sales')); ?>">Export CSV</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(auth('staff')->user()->can('sales.manage')): ?>
<form class="panel" method="post" action="<?php echo e(route('dealer.sales.store')); ?>" style="margin:1rem 0;">
    <?php echo csrf_field(); ?>
    <div class="row">
        <select name="vehicle_id" required><option value="">Car</option><?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($car->id); ?>"><?php echo e($car->title()); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        <select name="customer_id" required><option value="">Customer</option><?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
        <input name="price" type="number" step="0.01" placeholder="Price £" required>
        <input type="date" name="sold_on" required value="<?php echo e(now()->toDateString()); ?>">
        <select name="method"><?php $__currentLoopData = ['bank_transfer','card','finance','cash']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($method); ?>"><?php echo e(str_replace('_',' ', $method)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    </div>
    <label>Part exchange</label>
    <select name="part_exchange_valuation_id"><option value="">None</option><?php $__currentLoopData = $valuations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valuation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($valuation->id); ?>"><?php echo e($valuation->registration); ?> <?php echo e($valuation->make); ?> <?php echo e($valuation->model); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
    <label>Notes</label><textarea name="notes"></textarea>
    <button class="btn" type="submit">Record sale</button>
</form>
<?php endif; ?>
<div class="panel table-scroll">
    <table class="data-table">
        <thead>
            <tr><th class="sno">S.no</th><th>Date</th><th>Car</th><th>Customer</th><th class="num">Price</th><th>Invoice</th><th></th></tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="sno"><?php echo e($rows->firstItem() + $loop->index); ?></td>
                    <td><?php echo e($row->sold_on?->format('j M Y')); ?></td>
                    <td><?php echo e($row->vehicle_label); ?> <span class="badge <?php echo e($row->status); ?>"><?php echo e(ucfirst($row->status)); ?></span></td>
                    <td><?php if($row->customer): ?><a href="<?php echo e(route('dealer.customers.show', $row->customer)); ?>"><?php echo e($row->customer->name); ?></a><?php endif; ?></td>
                    <td class="num"><?php echo e(\App\Support\Money::gbp($row->price_pence)); ?></td>
                    <td><?php if($row->invoice): ?><a href="<?php echo e(route('dealer.invoices.show', $row->invoice)); ?>"><?php echo e($row->invoice->number); ?></a><?php else: ?> — <?php endif; ?></td>
                    <td class="row-actions">
                        <a class="rowbtn" href="<?php echo e(route('dealer.sales.show', $row)); ?>">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7" class="empty-row">No sales recorded yet.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/sales.blade.php ENDPATH**/ ?>