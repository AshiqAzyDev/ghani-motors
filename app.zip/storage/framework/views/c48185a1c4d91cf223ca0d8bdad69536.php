<?php $__env->startSection('title', 'Finance'); ?>
<?php $__env->startSection('description', 'An illustrative finance example for used cars at Ghani Motors. This is not a quote or a credit check.'); ?>
<?php $__env->startSection('content'); ?>
<section class="pageintro">
    <div class="crumb"><a href="<?php echo e(route('home')); ?>">Home</a> / Car finance</div>
    <div class="eyebrow">Explore your possibilities</div>
    <h1>A next step that fits your budget.</h1>
    <p class="sub">Explore an illustrative monthly payment, then talk to our team about finance options.</p>
</section>
<section class="section finance-grid">
    <div class="panel calc" data-calculator>
        <h2>Make the numbers work for you.</h2>
        <p>Adjust the amount, deposit and term to see an example.</p>
        <?php if($car): ?>
            <p><strong><?php echo e($car->title()); ?></strong></p>
        <?php endif; ?>
        <label>Vehicle price <span class="calcvalue" data-price-label></span>
            <input type="range" name="price" min="1000" max="<?php echo e(max(40000, $car ? intdiv((int) $car->publicPricePence(), 100) : 40000)); ?>" step="50" value="<?php echo e($car ? intdiv((int) $car->publicPricePence(), 100) : 15995); ?>">
        </label>
        <label>Deposit <span class="calcvalue" data-deposit-label></span>
            <input type="range" name="deposit" min="0" max="<?php echo e($car ? intdiv((int) $car->publicPricePence(), 100) : 15995); ?>" step="50" value="2000">
        </label>
        <label>Agreement length
            <select name="months">
                <?php $__currentLoopData = [24, 36, 48, 60]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $months): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($months); ?>" <?php if($months === 48): echo 'selected'; endif; ?>><?php echo e($months); ?> months</option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </label>
        <div class="payment">
            <small>ILLUSTRATIVE MONTHLY PAYMENT</small>
            <strong data-payment>—</strong>
            <small>Calculated at an assumed 12.9% annual rate</small>
        </div>
        <p class="sample">This is an illustration, not a finance offer or a credit check. Actual APR, fees and eligibility depend on the lender.</p>
    </div>
    <div>
        <div class="eyebrow">Let’s find a way forward</div>
        <h2>Finance starts<br>with a conversation.</h2>
        <p class="sub">Tell us which car you’re interested in and how to reach you.</p>
        <form class="panel" method="post" action="<?php echo e(route('finance.store')); ?>">
            <?php echo csrf_field(); ?>
            <?php if($car): ?><input type="hidden" name="car" value="<?php echo e($car->slug); ?>"><?php endif; ?>
            <?php echo $__env->make('partials.contact-fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <label>Message<textarea name="message"><?php echo e(old('message')); ?></textarea></label>
            <button class="btn" type="submit" style="margin-top:1rem;">Send enquiry</button>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/site/finance.blade.php ENDPATH**/ ?>