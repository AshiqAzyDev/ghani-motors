<?php
    $live = $car->show_on_website && $car->website_status !== 'sold' && $car->website_status !== 'hidden';
    $image = $car->images->first();
?>
<article class="account-saved-card <?php if (! ($live)): ?> is-gone <?php endif; ?>">
    <a class="account-saved-media" href="<?php echo e($live && $car->slug ? route('cars.show', $car->slug) : route('stock')); ?>">
        <?php if($image): ?>
            <img src="<?php echo e($image->sized('w800h600')); ?>" alt="<?php echo e($car->title()); ?>" loading="lazy">
        <?php else: ?>
            <div class="account-saved-placeholder">No photo</div>
        <?php endif; ?>
        <?php if (! ($live)): ?>
            <span class="account-saved-chip">No longer available</span>
        <?php endif; ?>
    </a>
    <div class="account-saved-body">
        <b><?php echo e($car->title()); ?></b>
        <p class="meta">
            <?php if($live): ?>
                <?php echo e(\App\Support\Money::gbp($car->publicPricePence())); ?> · <?php echo e(ucfirst($car->website_status)); ?>

            <?php else: ?>
                Removed from public stock
            <?php endif; ?>
        </p>
        <div class="account-saved-actions">
            <?php if($live && $car->slug): ?>
                <a class="btn smallbtn" href="<?php echo e(route('cars.show', $car->slug)); ?>">View car</a>
            <?php endif; ?>
            <form method="post" action="<?php echo e(route('account.unsave', $car)); ?>"><?php echo csrf_field(); ?><button class="btn smallbtn ghost" type="submit">Unsave</button></form>
        </div>
    </div>
</article>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account/partials/saved-card.blade.php ENDPATH**/ ?>