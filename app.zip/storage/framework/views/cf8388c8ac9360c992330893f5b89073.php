<?php $__env->startSection('title', 'Settings'); ?>
<?php $__env->startSection('content'); ?>
<?php ($canEdit = auth('staff')->user()->can('settings.manage')); ?>
<p class="page-note">Website branding, contact details, and Autotrader integration.</p>
<?php if (! ($canEdit)): ?>
    <p class="meta">Your role can view settings but cannot change them.</p>
<?php endif; ?>

<form method="post" action="<?php echo e(route('dealer.settings.update')); ?>" enctype="multipart/form-data" class="settings-form">
    <?php echo csrf_field(); ?>
    <div class="settings-grid">
        <section class="panel">
            <h2>Branding</h2>
            <p class="meta">Logo and favicon appear on the public website. Use PNG, JPG, or WebP (ICO also allowed for favicon). SVG is not supported.</p>
            <div class="settings-brand-row">
                <div>
                    <label>Logo</label>
                    <?php if($dealer->logoUrl()): ?>
                        <div class="settings-preview"><img src="<?php echo e($dealer->logoUrl()); ?>" alt="Current logo"></div>
                        <?php if($canEdit): ?>
                            <label class="check-inline"><input type="checkbox" name="remove_logo" value="1"> Remove current logo</label>
                        <?php endif; ?>
                    <?php endif; ?>
                    <input type="file" name="logo" accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp" <?php if(! $canEdit): echo 'disabled'; endif; ?>>
                </div>
                <div>
                    <label>Favicon</label>
                    <?php if($dealer->faviconUrl()): ?>
                        <div class="settings-preview favicon"><img src="<?php echo e($dealer->faviconUrl()); ?>" alt="Current favicon"></div>
                        <?php if($canEdit): ?>
                            <label class="check-inline"><input type="checkbox" name="remove_favicon" value="1"> Remove current favicon</label>
                        <?php endif; ?>
                    <?php endif; ?>
                    <input type="file" name="favicon" accept=".png,.jpg,.jpeg,.webp,.ico,image/png,image/jpeg,image/webp,image/x-icon,image/vnd.microsoft.icon" <?php if(! $canEdit): echo 'disabled'; endif; ?>>
                </div>
            </div>
            <label>Business name<input name="name" value="<?php echo e(old('name', $dealer->name)); ?>" required <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
            <label>Trading name<input name="trading_name" value="<?php echo e(old('trading_name', $dealer->trading_name)); ?>" placeholder="Ghani Motors" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
            <label>Tagline<input name="tagline" value="<?php echo e(old('tagline', $dealer->tagline)); ?>" placeholder="QUALITY USED CARS" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
        </section>

        <section class="panel">
            <h2>Contact &amp; showroom</h2>
            <p class="meta">Phone drives the floating WhatsApp button. Use a UK mobile such as 07907 669002 or +44 7907 669002.</p>
            <p class="meta">WhatsApp button: <strong><?php echo e($autotrader['whatsapp_live'] ? 'live on the website' : 'hidden until a real number is saved'); ?></strong></p>
            <label>Public email<input type="email" name="email" value="<?php echo e(old('email', $dealer->email)); ?>" placeholder="sales@ghanimotors.co.uk" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
            <label>Phone<input name="phone" value="<?php echo e(old('phone', $dealer->phone)); ?>" required placeholder="07907 669002" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
            <label>Address line<input name="address_line" value="<?php echo e(old('address_line', $dealer->address_line)); ?>" placeholder="Rainham Road South" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
            <div class="settings-two">
                <label>City<input name="city" value="<?php echo e(old('city', $dealer->city)); ?>" placeholder="Dagenham" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
                <label>Postcode<input name="postcode" value="<?php echo e(old('postcode', $dealer->postcode)); ?>" placeholder="RM10 8YT" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
            </div>
            <label>Opening hours<input name="opening_hours" value="<?php echo e(old('opening_hours', $dealer->opening_hours)); ?>" placeholder="Mon–Sat 9am–6pm" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
            <label>Website host<input name="website_host" value="<?php echo e(old('website_host', $dealer->website_host)); ?>" placeholder="ghanimotors.co.uk" <?php if(! $canEdit): echo 'readonly'; endif; ?>></label>
        </section>
    </div>

    <?php if($canEdit): ?>
        <button class="btn" type="submit" style="margin-top:1rem;">Save website settings</button>
    <?php endif; ?>
</form>

<section class="panel" style="margin-top:1.25rem;">
    <h2>Autotrader integration</h2>
    <div class="at-status">
        <div class="at-status-row">
            <span>Environment</span>
            <strong class="at-pill"><?php echo e($autotrader['environment']); ?></strong>
        </div>
        <div class="at-status-row">
            <span>API credentials</span>
            <strong class="at-pill <?php echo e($autotrader['key_set'] ? 'ok' : 'bad'); ?>"><?php echo e($autotrader['key_set'] ? 'Set in .env' : 'Missing'); ?></strong>
        </div>
        <div class="at-status-row">
            <span>Webhook secret</span>
            <strong class="at-pill <?php echo e($autotrader['webhook_set'] ? 'ok' : 'warn'); ?>"><?php echo e($autotrader['webhook_set'] ? 'Set' : 'Not set — live stock updates blocked'); ?></strong>
        </div>
        <div class="at-status-row">
            <span>Sandbox expiry</span>
            <strong class="at-pill <?php echo e($autotrader['sandbox_state']); ?>"><?php echo e($autotrader['sandbox_label']); ?></strong>
        </div>
        <div class="at-status-row">
            <span>Advertiser</span>
            <strong><?php echo e($autotrader['advertiser_id'] ?: 'not set'); ?> · on integration: <?php echo e($autotrader['on_integration'] ? 'yes' : 'no'); ?></strong>
        </div>
        <div class="at-status-row">
            <span>API host</span>
            <strong style="font-weight:500;word-break:break-all;"><?php echo e($autotrader['base_url']); ?></strong>
        </div>
        <div class="at-status-row">
            <span>Webhook URL</span>
            <strong style="font-weight:500;word-break:break-all;"><?php echo e(url('/webhooks/autotrader')); ?></strong>
        </div>
    </div>
    <p style="margin-top:.85rem;">Notifications <?php echo e($dealer->integration->notifications_paused ? 'paused' : 'running'); ?>. Open API pauses: <?php echo e($blocks); ?>. Failed webhooks: <?php echo e($failedHooks); ?>.</p>
    <p>Last sync: <?php echo e($lastSync ? $lastSync->kind.' '.$lastSync->status.' at '.$lastSync->created_at : 'none yet'); ?>.</p>
    <?php if($autotrader['environment'] === 'sandbox' && $autotrader['sandbox_state'] === 'unknown'): ?>
        <p class="meta">Set <code>AUTOTRADER_SANDBOX_EXPIRES_AT</code> in <code>.env</code> (YYYY-MM-DD) when Autotrader confirms the end date.</p>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('sync.run')): ?>
        <form method="post" action="<?php echo e(route('dealer.sync')); ?>" style="margin-top:.75rem;"><?php echo csrf_field(); ?><button class="btn" type="submit">Run Autotrader baseline</button></form>
    <?php endif; ?>
</section>

<?php ($migrationStatus = $migrationStatus ?? []); ?>
<?php ($migrationState = $migrationStatus['state'] ?? 'error'); ?>
<?php ($pendingMigrations = $migrationStatus['pending'] ?? []); ?>
<?php ($migrationPillClass = $migrationState === 'up_to_date' ? 'ok' : ($migrationState === 'pending' ? 'warn' : 'bad')); ?>
<?php ($migrationPillLabel = $migrationState === 'up_to_date' ? 'Up to date' : ($migrationState === 'pending' ? 'Migrations pending' : 'Check failed')); ?>
<section id="settings-database" class="panel" style="margin-top:1.25rem;">
    <h2>Database migrations</h2>
    <p class="meta">Apply pending schema updates without wiping the live database.</p>
    <p class="page-note" style="margin-top:.75rem;">
        This runs <code>php artisan migrate</code> for files that have not run yet.
        If a table already exists, migrations add any <strong>missing columns</strong> only — they do not drop,
        truncate, or recreate tables. This is not <code>migrate:fresh</code>.
    </p>

    <div class="at-status" style="margin-top:1rem;">
        <div class="at-status-row">
            <span>Status</span>
            <strong class="at-pill <?php echo e($migrationPillClass); ?>"><?php echo e($migrationPillLabel); ?></strong>
        </div>
        <div class="at-status-row">
            <span>Database</span>
            <strong><?php echo e($migrationStatus['database'] ?? config('database.default')); ?></strong>
        </div>
        <div class="at-status-row">
            <span>Applied / files</span>
            <strong><?php echo e($migrationStatus['applied_count'] ?? 0); ?> / <?php echo e($migrationStatus['expected_count'] ?? 0); ?> · Pending: <?php echo e(count($pendingMigrations)); ?></strong>
        </div>
    </div>

    <p style="margin-top:.85rem;"><?php echo e($migrationStatus['message'] ?? 'Unable to read migration status.'); ?></p>

    <?php if($pendingMigrations !== []): ?>
        <div class="migration-pending" style="margin-top:.85rem;">
            <p class="meta" style="margin-bottom:.35rem;">Pending migrations (<?php echo e(count($pendingMigrations)); ?>)</p>
            <ul class="migration-pending-list">
                <?php $__currentLoopData = $pendingMigrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $migrationName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><code><?php echo e($migrationName); ?></code></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <p class="meta" style="margin-top:.85rem;">
        Schema changes are applied from the server with
        <code>php artisan migrate</code>
        — not from the browser.
        <?php if($migrationState === 'up_to_date'): ?>
            No pending migrations.
        <?php elseif($migrationState === 'pending'): ?>
            Pending migrations need a CLI deploy or SSH run.
        <?php elseif($migrationState === 'error'): ?>
            Fix the database connection before migrating.
        <?php endif; ?>
    </p>
</section>

<section class="panel" style="margin-top:1.25rem;">
    <h2>Sync history</h2>
    <div class="panel table-scroll" style="padding:0;border:0;box-shadow:none;">
        <table class="data-table">
            <thead><tr><th>When</th><th>Kind</th><th>Status</th><th>Upserted</th><th>Error</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $syncRuns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $run): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(optional($run->started_at ?? $run->created_at)->format('j M Y H:i')); ?></td>
                        <td><?php echo e($run->kind); ?></td>
                        <td><span class="badge <?php echo e($run->status); ?>"><?php echo e(ucfirst($run->status)); ?></span></td>
                        <td><?php echo e($run->vehicles_upserted ?? '—'); ?></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($run->error, 80) ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="empty-row">No sync runs yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="panel" style="margin-top:1.25rem;">
    <h2>Recent webhooks</h2>
    <div class="panel table-scroll" style="padding:0;border:0;box-shadow:none;">
        <table class="data-table">
            <thead><tr><th>Received</th><th>Stock</th><th>Status</th><th>Detail</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $webhookEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e(optional($event->received_at)->format('j M Y H:i')); ?></td>
                        <td><?php echo e($event->stock_id ?: '—'); ?></td>
                        <td><span class="badge <?php echo e($event->status); ?>"><?php echo e(ucfirst($event->status)); ?></span></td>
                        <td><?php echo e(\Illuminate\Support\Str::limit($event->ignore_reason ?? '', 80) ?: '—'); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="4" class="empty-row">No webhook events yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/settings.blade.php ENDPATH**/ ?>