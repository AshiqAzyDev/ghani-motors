<?php $__env->startSection('title', 'Vehicles'); ?>
<?php $__env->startSection('actions'); ?>
    <?php if(auth('staff')->user()->can('vehicles.view')): ?>
        <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.export', 'vehicles')); ?>">Export CSV</a>
    <?php endif; ?>
    <?php if(auth('staff')->user()->can('vehicles.edit_manual')): ?>
        <a class="btn smallbtn" href="<?php echo e(route('dealer.vehicles.create')); ?>">Add manual car</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<nav class="source-tabs" aria-label="Vehicle source">
    <?php $__currentLoopData = ['autotrader' => 'Autotrader', 'manual' => 'Manual']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(route('dealer.vehicles', array_merge(request()->except(['page', 'source']), ['source' => $key]))); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => $source === $key]); ?>"><?php echo e($label); ?> <span><?php echo e($sourceCounts[$key] ?? 0); ?></span></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</nav>
<form class="list-bar" method="get">
    <input type="hidden" name="source" value="<?php echo e($source); ?>">
    <input name="q" placeholder="Registration, make or model" value="<?php echo e(request('q')); ?>">
    <select name="status">
        <option value="">Any status</option>
        <?php $__currentLoopData = ['available','reserved','preparation','sold','hidden']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($status); ?>" <?php if(request('status') === $status): echo 'selected'; endif; ?>><?php echo e(ucfirst($status)); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <button class="btn smallbtn" type="submit">Filter</button>
</form>
<div class="panel table-scroll">
    <table class="data-table vehicles-table">
        <thead>
            <tr>
                <th class="sno">S.no</th>
                <th>Registration</th>
                <th>Vehicle</th>
                <th>Year</th>
                <th>Mileage</th>
                <th>Fuel</th>
                <th>Status</th>
                <th class="num">Price</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="sno"><?php echo e($cars->firstItem() + $loop->index); ?></td>
                    <td class="vrm"><?php echo e($car->registration ?: '—'); ?></td>
                    <td>
                        <b><?php echo e(trim($car->make.' '.$car->model) ?: '—'); ?></b>
                        <?php if($car->trim): ?><small><?php echo e($car->trim); ?></small><?php endif; ?>
                    </td>
                    <td><?php echo e($car->year ?: '—'); ?></td>
                    <td><?php echo e($car->mileage ? number_format($car->mileage) : '—'); ?></td>
                    <td><?php echo e($car->fuel ?: '—'); ?></td>
                    <td>
                        <span class="badge <?php echo e($car->website_status); ?>"><?php echo e(ucfirst($car->website_status)); ?></span>
                        <?php if($car->featured): ?><small>Featured</small><?php endif; ?>
                    </td>
                    <td class="num"><?php echo e(\App\Support\Money::gbp($car->publicPricePence())); ?></td>
                    <td class="row-actions">
                        <?php if(auth('staff')->user()->can('vehicles.edit_manual')): ?>
                            <a class="rowbtn" href="<?php echo e(route('dealer.vehicles.edit', $car)); ?>"><?php echo e($car->source === 'manual' ? 'Edit' : 'Internal'); ?></a>
                        <?php endif; ?>
                        <?php if(auth('staff')->user()->can('vehicles.feature') && ($car->show_on_website || $car->featured)): ?>
                            <form method="post" action="<?php echo e(route('dealer.vehicles.featured', $car)); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="featured" value="<?php echo e($car->featured ? 0 : 1); ?>">
                                <button class="rowbtn" type="submit"><?php echo e($car->featured ? 'Unfeature' : 'Feature'); ?></button>
                            </form>
                        <?php endif; ?>
                        <?php if(auth('staff')->user()->can('vehicles.edit_manual') && $car->source === 'manual' && ! $car->sales_exists): ?>
                            <form method="post" action="<?php echo e(route('dealer.vehicles.destroy', $car)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="rowbtn danger" type="submit">Remove</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="9" class="empty-row">No <?php echo e($source === 'manual' ? 'manual' : 'Autotrader'); ?> cars match this filter.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php echo e($cars->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/vehicles/index.blade.php ENDPATH**/ ?>