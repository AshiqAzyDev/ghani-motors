<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create an account | <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?></title>
    <meta name="description" content="Create a <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?> account to save cars and manage enquiries.">
    <?php if($siteDealer?->faviconUrl()): ?>
        <link rel="icon" href="<?php echo e($siteDealer->faviconUrl()); ?>">
    <?php endif; ?>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600;700&family=Manrope:wght@700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/upgrades.css')); ?>">
</head>
<body class="auth-body customer-auth" data-saved="<?php echo e(implode(',', session('saved_vehicle_ids', []))); ?>">
<main class="auth-shell">
    <aside class="auth-aside">
        <a class="auth-brand" href="<?php echo e(route('home')); ?>">
            <?php if($siteDealer?->logoUrl()): ?>
                <img class="brand-logo" src="<?php echo e($siteDealer->logoUrl()); ?>" alt="<?php echo e($siteDealer->displayName()); ?>">
            <?php else: ?>
                <b>GHANI <span>MOTORS</span></b>
                <small><?php echo e($siteDealer?->displayTagline() ?? 'Quality used cars'); ?></small>
            <?php endif; ?>
        </a>
        <p class="auth-kicker">Customer account</p>
        <h1>Create an account in a couple of minutes.</h1>
        <p>Save cars from the forecourt and keep your details ready when you enquire or book a viewing.</p>
        <?php echo $__env->make('partials.aa-badge', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <a class="auth-back" href="<?php echo e(route('login')); ?>">← Back to log in</a>
    </aside>
    <section class="auth-card">
        <form method="post" action="<?php echo e(route('register')); ?>">
            <?php echo csrf_field(); ?>
            <h2>Create an account</h2>
            <p class="meta">We’ll use these details when you contact the team.</p>
            <?php if($errors->any()): ?>
                <div class="errors">
                    <ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
                </div>
            <?php endif; ?>
            <input type="hidden" name="saved_ids" value="">
            <label for="name">Name</label>
            <input id="name" name="name" required autocomplete="name" value="<?php echo e(old('name')); ?>">
            <label for="email">Email</label>
            <input id="email" type="email" name="email" required autocomplete="email" value="<?php echo e(old('email')); ?>">
            <label for="phone">Phone</label>
            <input id="phone" name="phone" required autocomplete="tel" value="<?php echo e(old('phone')); ?>">
            <?php echo $__env->make('partials.password-field', ['id' => 'password', 'autocomplete' => 'new-password'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <label for="password_confirmation">Confirm password</label>
            <div class="password-field">
                <input id="password_confirmation" type="password" name="password_confirmation" required autocomplete="new-password">
            </div>
            <label class="auth-terms">
                <input type="checkbox" name="accepted_terms" value="1" required>
                <span>I accept the <a href="<?php echo e(route('privacy')); ?>">privacy terms</a></span>
            </label>
            <button class="btn" type="submit">Create account</button>
            <p class="auth-foot">Already have an account? <a href="<?php echo e(route('login')); ?>">Log in</a></p>
        </form>
    </section>
</main>
<script src="<?php echo e(asset('js/site.js')); ?>"></script>
</body>
</html>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/auth/register.blade.php ENDPATH**/ ?>