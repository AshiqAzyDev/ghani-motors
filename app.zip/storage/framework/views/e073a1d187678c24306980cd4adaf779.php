
<?php $__env->startSection('body'); ?>
<p style="margin:0 0 12px;">Hi <?php echo e($name); ?>,</p>
<p style="margin:0 0 12px;">Use the button below to choose a new password for your Ghani Motors account. This link expires in 60 minutes.</p>
<p style="margin:0;">If you did not ask for a reset, you can ignore this email.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('emails.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/emails/customer/password-reset.blade.php ENDPATH**/ ?>