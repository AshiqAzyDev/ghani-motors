<!DOCTYPE html>
<html lang="en-GB">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex">
    <title><?php echo $__env->yieldContent('title', 'Dealer'); ?> | <?php echo e($siteDealer?->displayName() ?? 'Ghani Motors'); ?></title>
    <?php if($siteDealer?->faviconUrl()): ?>
        <link rel="icon" href="<?php echo e($siteDealer->faviconUrl()); ?>">
    <?php endif; ?>
    <link rel="stylesheet" href="<?php echo e(asset('fonts/site-fonts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/upgrades.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/dealer-upgrades.min.css')); ?>">
</head>
<body class="dealer-mode">
<?php
    $nav = [
        'dealer.home' => 'Overview',
        'dealer.vehicles' => 'Vehicles',
        'dealer.bookings' => 'Bookings',
        'dealer.customers' => 'Customers',
        'dealer.leads' => 'Leads',
        'dealer.sales' => 'Sales records',
        'dealer.invoices' => 'Invoices',
        'dealer.staff' => 'Staff',
        'dealer.settings' => 'Settings',
    ];
    $permMap = \App\Support\StaffPermissions::navMap();
?>
    <div class="dealer-app">
        <aside class="dealer-sidebar">
            <a class="dealer-brand" href="<?php echo e(route('dealer.home')); ?>">
                <?php if($siteDealer?->logoUrl()): ?>
                    <img class="dealer-brand-logo" src="<?php echo e($siteDealer->logoUrl()); ?>" alt="<?php echo e($siteDealer->displayName()); ?>">
                <?php else: ?>
                    <span>GHANI</span> MOTORS
                <?php endif; ?>
                <small>DEALER WORKSPACE</small>
            </a>
            <div class="workspace-label">MANAGE YOUR DEALERSHIP</div>
            <nav class="dealer-nav" aria-label="Dealer navigation">
                <?php $__currentLoopData = $nav; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($need = $permMap[$route] ?? null); ?>
                    <?php if(! $need || ($dealerStaff && $dealerStaff->can($need))): ?>
                        <a href="<?php echo e(route($route)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request()->routeIs($route) || request()->routeIs(str_replace('.home', '', $route).'.*') || ($route === 'dealer.leads' && request()->routeIs('dealer.leads.*')) || ($route === 'dealer.customers' && request()->routeIs('dealer.customers.*')) || ($route === 'dealer.staff' && request()->routeIs('dealer.staff.*')) || ($route === 'dealer.invoices' && request()->routeIs('dealer.invoices.*')) || ($route === 'dealer.vehicles' && request()->routeIs('dealer.vehicles.*'))]); ?>"><?php echo e($label); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </nav>
            <div class="dealer-sidebottom">
                <div class="feed-status"><i></i> Stock feed</div>
                <p>Autotrader stock stays in sync from here. Manual cars stay off the public site.</p>
                <a href="<?php echo e(route('home')); ?>">View the website ↗</a>
            </div>
        </aside>
        <div class="dealer-main">
            <div class="dealer-top">
                <div>
                    <small><?php echo e($siteDealer?->displayName() ?? 'GHANI MOTORS'); ?><?php if($dealerStaff): ?> · <?php echo e($dealerStaff->name); ?> (<?php echo e($dealerStaff->role); ?>)<?php endif; ?></small>
                    <h1><?php echo $__env->yieldContent('title', 'Dealer'); ?></h1>
                </div>
                <div class="dealer-topactions">
                    <a class="dealer-view-site btn smallbtn ghost" href="<?php echo e(route('home')); ?>">View website</a>
                    <?php echo $__env->make('partials.dealer-notifications', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <?php echo $__env->yieldContent('actions'); ?>
                    <form method="post" action="<?php echo e(route('dealer.logout')); ?>"><?php echo csrf_field(); ?><button class="btn smallbtn" type="submit">Log out</button></form>
                </div>
            </div>
            <div class="dealer-content">
                <?php if(session('status')): ?><p class="flash"><?php echo e(session('status')); ?></p><?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="errors"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
                <?php endif; ?>
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/dealer.js')); ?>" defer></script>
</body>
</html>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/layouts/dealer.blade.php ENDPATH**/ ?>