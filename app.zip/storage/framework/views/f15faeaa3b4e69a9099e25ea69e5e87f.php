<?php
    $image = $car->images->first();
?>
<article class="car home-car">
    <div class="carpic">
        <a href="<?php echo e(route('cars.show', $car->slug)); ?>" aria-label="View <?php echo e($car->title()); ?>">
            <?php if($image): ?>
                <img src="<?php echo e($image->sized('w800h600')); ?>" alt="<?php echo e($car->title()); ?>">
            <?php endif; ?>
        </a>
        <span class="tag"><?php echo e(ucfirst($car->website_status)); ?></span>
        <form method="post" action="<?php echo e(route('cars.save', $car->slug)); ?>">
            <?php echo csrf_field(); ?>
            <button class="heart" type="submit" data-save="<?php echo e($car->id); ?>" aria-label="Save <?php echo e($car->title()); ?>">♡</button>
        </form>
    </div>
    <div class="cardbody">
        <a href="<?php echo e(route('cars.show', $car->slug)); ?>"><h3><?php echo e($car->make); ?> <?php echo e($car->model); ?></h3></a>
        <p><?php echo e($car->trim ?: $car->attention_grabber); ?></p>
        <div class="specs">
            <?php if($car->year): ?><span><?php echo e($car->year); ?></span><?php endif; ?>
            <?php if($car->mileage !== null): ?><span><?php echo e(number_format((int) $car->mileage)); ?> miles</span><?php endif; ?>
            <?php if($car->transmission): ?><span><?php echo e($car->transmission); ?></span><?php endif; ?>
            <?php if($car->fuel): ?><span><?php echo e($car->fuel); ?></span><?php endif; ?>
        </div>
        <div class="price">
            <div>
                <small class="cashlabel">Cash price</small>
                <strong><?php echo e(\App\Support\Money::gbp($car->publicPricePence())); ?></strong>
            </div>
            <a href="<?php echo e(route('cars.show', $car->slug)); ?>">View car ↗</a>
        </div>
    </div>
</article>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/partials/car-card.blade.php ENDPATH**/ ?>