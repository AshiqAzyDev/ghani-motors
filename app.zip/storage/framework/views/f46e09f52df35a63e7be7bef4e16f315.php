<?php $__env->startSection('title', 'Booking'); ?>
<?php $__env->startSection('actions'); ?>
    <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.bookings')); ?>">Back to bookings</a>
    <?php if($booking->customer): ?>
        <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.customers.show', $booking->customer)); ?>">Open customer</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $vehicle = $booking->vehicle;
    $customer = $booking->customer;
    $image = $vehicle?->images?->first();
    $price = $vehicle?->publicPricePence();
    $typeLabel = ucfirst(str_replace('_', ' ', $booking->type));
    $statusLabel = ucfirst($booking->status);
    $timeLabel = $booking->preferred_time ? \Illuminate\Support\Str::of($booking->preferred_time)->substr(0, 5) : null;
    $days = $booking->preferred_on ? (int) now()->startOfDay()->diffInDays($booking->preferred_on->copy()->startOfDay(), false) : null;
    $countdown = match (true) {
        $days === null => null,
        $days > 1 => "Upcoming in {$days} days",
        $days === 1 => 'Upcoming tomorrow',
        $days === 0 => 'Scheduled for today',
        $days === -1 => 'Was yesterday',
        default => 'Past appointment',
    };
    $initials = collect(preg_split('/\s+/', trim((string) ($customer?->name ?? ''))))
        ->filter()
        ->take(2)
        ->map(fn ($part) => \Illuminate\Support\Str::upper(\Illuminate\Support\Str::substr($part, 0, 1)))
        ->implode('') ?: '?';
?>
<div class="hub-page">
    <section class="hub-banner">
        <div>
            <div class="hub-banner-title">
                <h2>Booking Details</h2>
                <span class="hub-pill hub-pill-type"><?php echo e($typeLabel); ?></span>
                <span class="hub-pill hub-pill-status <?php echo e($booking->status); ?>">
                    <span class="hub-pill-dot" aria-hidden="true"></span>
                    <?php echo e($statusLabel); ?>

                </span>
            </div>
            <div class="hub-banner-meta">
                <span>Scheduled:</span>
                <strong><?php echo e(optional($booking->preferred_on)->format('j M Y') ?: '—'); ?></strong>
                <?php if($timeLabel): ?>
                    <span class="sep">•</span>
                    <strong><?php echo e($timeLabel); ?></strong>
                <?php endif; ?>
            </div>
        </div>
        <?php if($countdown): ?>
            <div class="hub-countdown <?php echo e($days !== null && $days < 0 ? 'is-past' : ''); ?>">
                <i aria-hidden="true"></i>
                <span>Appointment status: <b><?php echo e($countdown); ?></b></span>
            </div>
        <?php endif; ?>
    </section>

    <div class="hub-grid">
        <div class="hub-main">
            <article class="hub-card">
                <div class="hub-card-head">
                    <span>Selected Vehicle</span>
                    <?php if($vehicle?->slug): ?>
                        <a class="hub-card-link" href="<?php echo e(route('cars.show', $vehicle->slug)); ?>" target="_blank" rel="noopener">View stock item →</a>
                    <?php endif; ?>
                </div>
                <div class="hub-vehicle-body">
                    <?php if($image): ?>
                        <div class="hub-vehicle-thumb">
                            <img src="<?php echo e($image->sized('w400h300')); ?>" alt="<?php echo e($vehicle?->title()); ?>">
                            <span class="hub-thumb-label"><?php echo e(ucfirst($vehicle?->website_status ?: 'Stock')); ?></span>
                        </div>
                    <?php else: ?>
                        <div class="hub-vehicle-thumb is-empty">No photo</div>
                    <?php endif; ?>
                    <div class="hub-vehicle-copy">
                        <div class="hub-vehicle-top">
                            <div>
                                <h3><?php echo e($vehicle?->title() ?: '—'); ?></h3>
                                <p class="hub-sub">
                                    <?php echo e(collect([$vehicle?->body, $vehicle?->fuel, $vehicle?->transmission])->filter()->implode(' · ') ?: 'Vehicle details'); ?>

                                </p>
                            </div>
                            <?php if($price !== null): ?>
                                <div class="hub-price"><?php echo e(\App\Support\Money::gbp($price)); ?></div>
                            <?php endif; ?>
                        </div>
                        <div class="hub-specs">
                            <?php if($vehicle?->registration): ?>
                                <span class="hub-reg"><?php echo e($vehicle->registration); ?></span>
                            <?php endif; ?>
                            <?php if($vehicle?->mileage !== null): ?>
                                <span class="hub-chip"><?php echo e(number_format($vehicle->mileage)); ?> mi</span>
                            <?php endif; ?>
                            <?php if($vehicle?->fuel): ?>
                                <span class="hub-chip"><?php echo e($vehicle->fuel); ?></span>
                            <?php endif; ?>
                            <?php if($vehicle?->transmission): ?>
                                <span class="hub-chip"><?php echo e($vehicle->transmission); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </article>

            <article class="hub-card">
                <div class="hub-card-head">
                    <span>Customer &amp; Contact Information</span>
                    <?php if($customer): ?>
                        <a class="hub-card-link" href="<?php echo e(route('dealer.customers.show', $customer)); ?>">Open full profile →</a>
                    <?php endif; ?>
                </div>
                <div class="hub-customer-grid">
                    <div class="hub-customer-profile">
                        <div class="hub-avatar" aria-hidden="true"><?php echo e($initials); ?></div>
                        <div>
                            <h4><?php echo e($customer?->name ?: '—'); ?></h4>
                            <p class="hub-sub"><?php echo e($customer?->email ?: 'No email on file'); ?></p>
                        </div>
                    </div>
                    <div class="hub-contact">
                        <div class="hub-contact-row">
                            <span>Email:
                                <?php if($customer?->email): ?>
                                    <a href="mailto:<?php echo e($customer->email); ?>"><?php echo e($customer->email); ?></a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="hub-contact-row">
                            <span>Phone:
                                <?php if($customer?->phone): ?>
                                    <a href="tel:<?php echo e(preg_replace('/\s+/', '', $customer->phone)); ?>"><?php echo e($customer->phone); ?></a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </span>
                            <?php if($customer?->phone): ?>
                                <a class="hub-call" href="tel:<?php echo e(preg_replace('/\s+/', '', $customer->phone)); ?>">Call now</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php if($booking->notes): ?>
                    <div class="hub-notes">
                        <span>Internal appointment notes</span>
                        <div class="hub-notes-box"><?php echo e($booking->notes); ?></div>
                    </div>
                <?php endif; ?>
            </article>
        </div>

        <aside class="hub-card hub-actions">
            <h3>Actions <small>Workflow</small></h3>
            <div class="hub-actions-stack">
                <?php if(auth('staff')->user()->can('bookings.manage')): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $booking->nextStatuses(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $next): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <form method="post" action="<?php echo e(route('dealer.bookings.status', $booking)); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="status" value="<?php echo e($next); ?>">
                            <button
                                class="hub-btn <?php echo e($next === 'cancelled' ? 'hub-btn-danger' : ($next === 'completed' || $next === 'confirmed' ? 'hub-btn-primary' : 'hub-btn-ghost')); ?>"
                                type="submit"
                            >Mark <?php echo e(ucfirst($next)); ?></button>
                        </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="meta">No status changes available.</p>
                    <?php endif; ?>
                <?php else: ?>
                    <p class="meta">View only — ask an admin if you need to update this booking.</p>
                <?php endif; ?>
            </div>
            <div class="hub-actions-foot">
                <a href="<?php echo e(route('dealer.bookings')); ?>">← Back to bookings list</a>
            </div>
        </aside>
    </div>

    <section class="hub-related">
        <div class="hub-related-head">
            <h3>Related History &amp; Activities</h3>
            <p>Connected leads, other bookings, sales and invoices for this customer.</p>
        </div>
        <div class="hub-related-grid">
            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-sky" aria-hidden="true"></i> Leads</span>
                    <span class="hub-related-count"><?php echo e($leads->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b><a href="<?php echo e(route('dealer.leads.show', $lead)); ?>"><?php echo e($lead->subject); ?></a></b>
                                <p class="hub-sub"><?php echo e(ucfirst(str_replace('_', ' ', $lead->type))); ?> · <?php echo e($lead->vehicle?->title()); ?></p>
                            </div>
                            <div class="hub-item-side">
                                <span class="hub-pill hub-pill-status <?php echo e($lead->status); ?>"><?php echo e(ucfirst($lead->status)); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No leads yet.</p>
                            <small>Enquiries linked to this customer will appear here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-amber" aria-hidden="true"></i> Other bookings</span>
                    <span class="hub-related-count"><?php echo e($otherBookings->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $otherBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b><a href="<?php echo e(route('dealer.bookings.show', $other)); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $other->type))); ?>: <?php echo e($other->vehicle?->title()); ?></a></b>
                                <p class="hub-sub"><?php echo e(optional($other->preferred_on)->format('j M Y')); ?></p>
                            </div>
                            <div class="hub-item-side">
                                <span class="hub-pill hub-pill-status <?php echo e($other->status); ?>"><?php echo e(ucfirst($other->status)); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No other bookings yet.</p>
                            <small>Earlier appointments for this customer show here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-emerald" aria-hidden="true"></i> Sales</span>
                    <span class="hub-related-count"><?php echo e($sales->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b><a href="<?php echo e(route('dealer.sales.show', $sale)); ?>"><?php echo e($sale->vehicle?->title() ?: $sale->vehicle_label); ?></a></b>
                                <p class="hub-sub"><?php echo e(optional($sale->sold_on)->format('j M Y')); ?> · <?php echo e(\App\Support\Money::gbp($sale->price_pence)); ?></p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No sales yet.</p>
                            <small>Completed sales for this customer will appear here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-indigo" aria-hidden="true"></i> Invoices</span>
                    <span class="hub-related-count"><?php echo e($invoices->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b>
                                    <?php if(auth('staff')->user()->can('invoices.view')): ?>
                                        <a href="<?php echo e(route('dealer.invoices.show', $invoice)); ?>"><?php echo e($invoice->number); ?></a>
                                    <?php else: ?>
                                        <?php echo e($invoice->number); ?>

                                    <?php endif; ?>
                                </b>
                                <p class="hub-sub"><?php echo e(\App\Support\Money::gbp($invoice->total_pence)); ?></p>
                            </div>
                            <div class="hub-item-side">
                                <span class="hub-pill hub-pill-status <?php echo e($invoice->status); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $invoice->status))); ?></span>
                                <?php if(auth('staff')->user()->can('invoices.view')): ?>
                                    <a class="hub-card-link" href="<?php echo e(route('dealer.invoices.print', $invoice)); ?>" target="_blank" rel="noopener">Print</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No invoices yet.</p>
                            <small>Billing documents for this customer show here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/bookings/show.blade.php ENDPATH**/ ?>