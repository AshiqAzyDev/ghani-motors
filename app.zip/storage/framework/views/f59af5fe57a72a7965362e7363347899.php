<?php $__env->startSection('title', 'Sale'); ?>
<?php $__env->startSection('actions'); ?>
    <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.sales')); ?>">Back to sales</a>
    <?php if($sale->customer): ?>
        <a class="btn smallbtn ghost" href="<?php echo e(route('dealer.customers.show', $sale->customer)); ?>">Open customer</a>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $vehicle = $sale->vehicle;
    $customer = $sale->customer;
    $image = $vehicle?->images?->first();
    $title = $vehicle?->title() ?: $sale->vehicle_label;
    $registration = $sale->registration ?: $vehicle?->registration;
    $statusLabel = ucfirst($sale->status);
    $methodLabel = ucfirst(str_replace('_', ' ', $sale->method));
    $initials = collect(preg_split('/\s+/', trim((string) ($customer?->name ?? ''))))
        ->filter()
        ->take(2)
        ->map(fn ($part) => \Illuminate\Support\Str::upper(\Illuminate\Support\Str::substr($part, 0, 1)))
        ->implode('') ?: '?';
    $px = $sale->partExchangeValuation;
?>
<div class="hub-page">
    <section class="hub-banner">
        <div>
            <div class="hub-banner-title">
                <h2>Sale Details</h2>
                <span class="hub-pill hub-pill-status <?php echo e($sale->status); ?>">
                    <span class="hub-pill-dot" aria-hidden="true"></span>
                    <?php echo e($statusLabel); ?>

                </span>
            </div>
            <div class="hub-banner-meta">
                <span>Sold:</span>
                <strong><?php echo e(optional($sale->sold_on)->format('j M Y') ?: '—'); ?></strong>
                <span class="sep">•</span>
                <strong><?php echo e($methodLabel); ?></strong>
                <span class="sep">•</span>
                <strong><?php echo e(\App\Support\Money::gbp($sale->price_pence)); ?></strong>
            </div>
        </div>
        <div class="hub-countdown <?php echo e($sale->status === 'completed' ? '' : 'is-past'); ?>">
            <i aria-hidden="true"></i>
            <span>Sale status: <b><?php echo e($statusLabel); ?></b></span>
        </div>
    </section>

    <div class="hub-grid">
        <div class="hub-main">
            <article class="hub-card">
                <div class="hub-card-head">
                    <span>Sold Vehicle</span>
                    <?php if($vehicle?->slug): ?>
                        <a class="hub-card-link" href="<?php echo e(route('cars.show', $vehicle->slug)); ?>" target="_blank" rel="noopener">View stock item →</a>
                    <?php endif; ?>
                </div>
                <div class="hub-vehicle-body">
                    <?php if($image): ?>
                        <div class="hub-vehicle-thumb">
                            <img src="<?php echo e($image->sized('w400h300')); ?>" alt="<?php echo e($title); ?>">
                            <span class="hub-thumb-label">Sold</span>
                        </div>
                    <?php else: ?>
                        <div class="hub-vehicle-thumb is-empty">No photo</div>
                    <?php endif; ?>
                    <div class="hub-vehicle-copy">
                        <div class="hub-vehicle-top">
                            <div>
                                <h3><?php echo e($title); ?></h3>
                                <p class="hub-sub">
                                    <?php echo e(collect([$vehicle?->body, $vehicle?->fuel, $vehicle?->transmission])->filter()->implode(' · ') ?: 'Vehicle details'); ?>

                                </p>
                            </div>
                            <div class="hub-price"><?php echo e(\App\Support\Money::gbp($sale->price_pence)); ?></div>
                        </div>
                        <div class="hub-specs">
                            <?php if($registration): ?>
                                <span class="hub-reg"><?php echo e($registration); ?></span>
                            <?php endif; ?>
                            <?php if($vehicle?->mileage !== null): ?>
                                <span class="hub-chip"><?php echo e(number_format($vehicle->mileage)); ?> mi</span>
                            <?php endif; ?>
                            <?php if($vehicle?->fuel): ?>
                                <span class="hub-chip"><?php echo e($vehicle->fuel); ?></span>
                            <?php endif; ?>
                            <?php if($vehicle?->transmission): ?>
                                <span class="hub-chip"><?php echo e($vehicle->transmission); ?></span>
                            <?php endif; ?>
                            <span class="hub-chip"><?php echo e($methodLabel); ?></span>
                        </div>
                    </div>
                </div>
            </article>

            <article class="hub-card">
                <div class="hub-card-head">
                    <span>Customer &amp; Contact Information</span>
                    <?php if($customer): ?>
                        <a class="hub-card-link" href="<?php echo e(route('dealer.customers.show', $customer)); ?>">Open full profile →</a>
                    <?php endif; ?>
                </div>
                <div class="hub-customer-grid">
                    <div class="hub-customer-profile">
                        <div class="hub-avatar" aria-hidden="true"><?php echo e($initials); ?></div>
                        <div>
                            <h4><?php echo e($customer?->name ?: '—'); ?></h4>
                            <p class="hub-sub"><?php echo e($customer?->email ?: 'No email on file'); ?></p>
                        </div>
                    </div>
                    <div class="hub-contact">
                        <div class="hub-contact-row">
                            <span>Email:
                                <?php if($customer?->email): ?>
                                    <a href="mailto:<?php echo e($customer->email); ?>"><?php echo e($customer->email); ?></a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </span>
                        </div>
                        <div class="hub-contact-row">
                            <span>Phone:
                                <?php if($customer?->phone): ?>
                                    <a href="tel:<?php echo e(preg_replace('/\s+/', '', $customer->phone)); ?>"><?php echo e($customer->phone); ?></a>
                                <?php else: ?>
                                    —
                                <?php endif; ?>
                            </span>
                            <?php if($customer?->phone): ?>
                                <a class="hub-call" href="tel:<?php echo e(preg_replace('/\s+/', '', $customer->phone)); ?>">Call now</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php if($px): ?>
                    <div class="hub-notes">
                        <span>Part exchange</span>
                        <div class="hub-notes-box"><?php echo e($px->registration); ?> · <?php echo e($px->make); ?> <?php echo e($px->model); ?></div>
                    </div>
                <?php endif; ?>
                <?php if($sale->notes): ?>
                    <div class="hub-notes">
                        <span>Sale notes</span>
                        <div class="hub-notes-box"><?php echo e($sale->notes); ?></div>
                    </div>
                <?php endif; ?>
            </article>
        </div>

        <aside class="hub-card hub-actions">
            <h3>Actions <small>Documents</small></h3>
            <div class="hub-actions-stack">
                <?php if($customer): ?>
                    <a class="hub-btn hub-btn-secondary" href="<?php echo e(route('dealer.customers.show', $customer)); ?>">Open customer</a>
                <?php endif; ?>
                <?php if($sale->invoice && auth('staff')->user()->can('invoices.view')): ?>
                    <a class="hub-btn hub-btn-primary" href="<?php echo e(route('dealer.invoices.show', $sale->invoice)); ?>">Open invoice <?php echo e($sale->invoice->number); ?></a>
                    <a class="hub-btn hub-btn-ghost" href="<?php echo e(route('dealer.invoices.print', $sale->invoice)); ?>" target="_blank" rel="noopener">Print invoice</a>
                <?php elseif(! $sale->invoice): ?>
                    <p class="meta">No invoice linked to this sale yet.</p>
                <?php endif; ?>
            </div>
            <div class="hub-actions-foot">
                <a href="<?php echo e(route('dealer.sales')); ?>">← Back to sales list</a>
            </div>
        </aside>
    </div>

    <section class="hub-related">
        <div class="hub-related-head">
            <h3>Related History &amp; Activities</h3>
            <p>Connected leads, bookings, other sales and invoices for this customer.</p>
        </div>
        <div class="hub-related-grid">
            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-sky" aria-hidden="true"></i> Leads</span>
                    <span class="hub-related-count"><?php echo e($leads->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b><a href="<?php echo e(route('dealer.leads.show', $lead)); ?>"><?php echo e($lead->subject); ?></a></b>
                                <p class="hub-sub"><?php echo e(ucfirst(str_replace('_', ' ', $lead->type))); ?> · <?php echo e($lead->vehicle?->title()); ?></p>
                            </div>
                            <div class="hub-item-side">
                                <span class="hub-pill hub-pill-status <?php echo e($lead->status); ?>"><?php echo e(ucfirst($lead->status)); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No leads yet.</p>
                            <small>Enquiries linked to this customer will appear here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-amber" aria-hidden="true"></i> Bookings</span>
                    <span class="hub-related-count"><?php echo e($bookings->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b><a href="<?php echo e(route('dealer.bookings.show', $booking)); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $booking->type))); ?>: <?php echo e($booking->vehicle?->title()); ?></a></b>
                                <p class="hub-sub"><?php echo e(optional($booking->preferred_on)->format('j M Y')); ?></p>
                            </div>
                            <div class="hub-item-side">
                                <span class="hub-pill hub-pill-status <?php echo e($booking->status); ?>"><?php echo e(ucfirst($booking->status)); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No bookings yet.</p>
                            <small>Appointments for this customer show here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-emerald" aria-hidden="true"></i> Other sales</span>
                    <span class="hub-related-count"><?php echo e($otherSales->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $otherSales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $other): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b><a href="<?php echo e(route('dealer.sales.show', $other)); ?>"><?php echo e($other->vehicle?->title() ?: $other->vehicle_label); ?></a></b>
                                <p class="hub-sub"><?php echo e(optional($other->sold_on)->format('j M Y')); ?> · <?php echo e(\App\Support\Money::gbp($other->price_pence)); ?></p>
                            </div>
                            <div class="hub-item-side">
                                <span class="hub-pill hub-pill-status <?php echo e($other->status); ?>"><?php echo e(ucfirst($other->status)); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No other sales yet.</p>
                            <small>Earlier sales for this customer show here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <div class="hub-card hub-related-card">
                <div class="hub-card-head">
                    <span><i class="hub-dot hub-dot-indigo" aria-hidden="true"></i> Invoices</span>
                    <span class="hub-related-count"><?php echo e($invoices->count()); ?></span>
                </div>
                <div class="hub-related-list">
                    <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="hub-related-item">
                            <div>
                                <b>
                                    <?php if(auth('staff')->user()->can('invoices.view')): ?>
                                        <a href="<?php echo e(route('dealer.invoices.show', $invoice)); ?>"><?php echo e($invoice->number); ?></a>
                                    <?php else: ?>
                                        <?php echo e($invoice->number); ?>

                                    <?php endif; ?>
                                </b>
                                <p class="hub-sub"><?php echo e(\App\Support\Money::gbp($invoice->total_pence)); ?></p>
                            </div>
                            <div class="hub-item-side">
                                <span class="hub-pill hub-pill-status <?php echo e($invoice->status); ?>"><?php echo e(ucfirst(str_replace('_', ' ', $invoice->status))); ?></span>
                                <?php if(auth('staff')->user()->can('invoices.view')): ?>
                                    <a class="hub-card-link" href="<?php echo e(route('dealer.invoices.print', $invoice)); ?>" target="_blank" rel="noopener">Print</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="hub-empty">
                            <p>No invoices yet.</p>
                            <small>Billing documents for this customer show here.</small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dealer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/dealer/sales/show.blade.php ENDPATH**/ ?>