<?php
    $pageOgImage = $car->images->first()?->sized('w800h600') ?: ($dealer->logoUrl() ?: asset('images/ghani-mail-logo.png'));
    $pageDescription = $car->title().' for sale at '.($dealer->displayName() ?? 'Ghani Motors').', '.($dealer->city ?? 'Dagenham').'.';
?>
<?php $__env->startSection('title', $car->title()); ?>
<?php $__env->startSection('description', $pageDescription); ?>
<?php $__env->startSection('og_image', $pageOgImage); ?>
<?php $__env->startSection('content'); ?>
<?php
    $price = $car->publicPricePence();
    $pounds = $price !== null ? intdiv($price, 100) : null;
    $plate = strtoupper(preg_replace('/\s+/', '', (string) $car->registration) ?? '');
    if (strlen($plate) === 7) {
        $plate = substr($plate, 0, 4).' '.substr($plate, 4);
    }
    $bodyNote = collect([$car->doors ? $car->doors.' doors' : null, $car->seats ? $car->seats.' seats' : null])->filter()->implode(' / ');
    $standard = $car->features->where('kind', 'standard')->values();
    $optional = $car->features->where('kind', 'optional')->values();
    $featureTotal = $car->highlights->count() + $car->features->count();
    $phone = $dealer->whatsappNumber();
    $ogImage = $car->images->first()?->sized('w800h600');
?>
<script type="application/ld+json">
<?php echo json_encode(array_filter([
    '<?php $__contextArgs = [];
if (context()->has($__contextArgs[0])) :
if (isset($value)) { $__contextPrevious[] = $value; }
$value = context()->get($__contextArgs[0]); ?>' => 'https://schema.org',
    '@type' => 'Car',
    'name' => $car->title(),
    'brand' => $car->make,
    'model' => $car->model,
    'vehicleModelDate' => $car->year,
    'fuelType' => $car->fuel,
    'vehicleTransmission' => $car->transmission,
    'color' => $car->colour,
    'image' => $ogImage,
    'offers' => $price ? ['@type' => 'Offer', 'priceCurrency' => 'GBP', 'price' => number_format($price / 100, 2, '.', ''), 'availability' => 'https://schema.org/InStock'] : null,
    'seller' => ['@type' => 'AutoDealer', 'name' => $dealer->displayName(), 'address' => $dealer->showroomAddress()],
]), JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE); ?>

</script>
<div class="car-page">
    <nav class="car-crumb" aria-label="Breadcrumb">
        <a href="<?php echo e(route('stock')); ?>">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M10 19l-7-7m0 0l7-7m-7 7h18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path></svg>
            Back to all cars
        </a>
        <span>/</span>
        <b><?php echo e($car->make); ?> <?php echo e($car->model); ?></b>
    </nav>

    <section class="car-card car-hero">
        <div>
            <div class="car-pills">
                <span class="car-status <?php echo e($car->website_status); ?>"><?php echo e(ucfirst($car->website_status)); ?></span>
                <?php if($plate !== ''): ?><span class="car-ref">Ref: <?php echo e($plate); ?></span><?php endif; ?>
            </div>
            <h1><?php echo e($car->title()); ?></h1>
            <?php if($car->attention_grabber): ?>
                <p class="car-lead"><?php echo e($car->attention_grabber); ?></p>
            <?php endif; ?>
            <div class="car-pills">
                <?php if($car->owners): ?>
                    <span><?php echo e($car->owners === 1 ? '1 owner' : $car->owners.' owners'); ?></span>
                <?php endif; ?>
                <?php if($car->mileage): ?>
                    <span><?php echo e(number_format($car->mileage)); ?> miles</span>
                <?php endif; ?>
                <?php $__currentLoopData = $car->highlights->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($highlight->name); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="car-pricebox">
            <small>Total vehicle price</small>
            <strong><?php echo e(\App\Support\Money::gbp($price)); ?></strong>
            <?php if($pounds): ?>
                <a href="#finance-calculator">See an illustrative monthly figure →</a>
            <?php endif; ?>
        </div>
    </section>

    <div class="car-layout">
        <div class="car-main">
            <section class="car-card car-gallery" data-gallery aria-label="Vehicle photos">
                <div class="car-stage">
                    <?php if($image = $car->images->first()): ?>
                        <img data-gallery-main src="<?php echo e($image->sized('w800h600')); ?>" alt="<?php echo e($car->title()); ?>">
                        <div class="car-stage-badges">
                            <span><?php echo e($car->images->count()); ?> <?php echo e(\Illuminate\Support\Str::plural('photo', $car->images->count())); ?></span>
                            <?php if($car->video_url): ?>
                                <a href="<?php echo e($car->video_url); ?>" target="_blank" rel="noopener">Walkaround video</a>
                            <?php endif; ?>
                        </div>
                        <button type="button" data-gallery-open aria-label="Enlarge image">Enlarge</button>
                    <?php else: ?>
                        <div class="car-stage-empty">Photos for this car will appear here.</div>
                    <?php endif; ?>
                </div>
                <?php if($car->images->count() > 1): ?>
                    <div class="car-thumbs">
                        <?php $__currentLoopData = $car->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <button type="button" data-gallery-thumb data-full="<?php echo e($thumb->sized('w800h600')); ?>" data-alt="<?php echo e($car->title()); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['is-selected' => $loop->first]); ?>">
                                <img src="<?php echo e($thumb->sized('w400h300')); ?>" alt="">
                            </button>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </section>

            <section class="car-card">
                <div class="car-section-head">
                    <div>
                        <h2>The details that matter.</h2>
                        <p>Key mechanical and physical specifications</p>
                    </div>
                </div>
                <div class="car-specs">
                    <?php $__currentLoopData = [
                        ['Year', $car->year, $car->first_registration_on?->format('j M Y')],
                        ['Mileage', $car->mileage ? number_format($car->mileage) : null, $car->mileage ? 'miles' : null],
                        ['Fuel', $car->fuel, null],
                        ['Gearbox', $car->transmission, null],
                        ['Body type', $car->body, $bodyNote ?: null],
                        ['Colour', $car->colour, null],
                        ['Keepers', $car->owners ? ($car->owners === 1 ? '1 owner' : $car->owners.' owners') : null, $car->history_previous_owners !== null ? $car->history_previous_owners.' previous' : null],
                        ['Engine', $car->engine_cc ? number_format($car->engine_cc).' cc' : null, null],
                        ['Registration', $plate !== '' ? $plate : null, null],
                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$label, $value, $note]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($value === null || $value === '') continue; ?>
                        <div>
                            <small><?php echo e($label); ?></small>
                            <b><?php echo e($value); ?></b>
                            <?php if($note): ?><span><?php echo e($note); ?></span><?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>

            <?php if($car->description || $car->description_2): ?>
                <section class="car-card">
                    <h2>About this car</h2>
                    <?php if($car->description): ?><p class="car-copy"><?php echo e($car->description); ?></p><?php endif; ?>
                    <?php if($car->description_2): ?><p class="car-copy"><?php echo e($car->description_2); ?></p><?php endif; ?>
                </section>
            <?php endif; ?>

            <?php if($featureTotal > 0): ?>
                <section class="car-card">
                    <div class="car-section-head">
                        <div>
                            <h2>Vehicle features and equipment</h2>
                            <p><?php echo e($featureTotal); ?> <?php echo e(\Illuminate\Support\Str::plural('item', $featureTotal)); ?> listed for this car</p>
                        </div>
                        <label class="car-search">
                            <span class="sr">Search equipment</span>
                            <input data-feature-search type="search" placeholder="Search equipment">
                        </label>
                    </div>
                    <?php if($car->highlights->isNotEmpty()): ?>
                        <div class="car-feature-group" data-feature-group>
                            <header>Highlights</header>
                            <div>
                                <?php $__currentLoopData = $car->highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="car-tick" data-feature="<?php echo e(strtolower($highlight->name)); ?>"><?php echo e($highlight->name); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($optional->isNotEmpty()): ?>
                        <div class="car-feature-group" data-feature-group>
                            <header>Optional equipment</header>
                            <div>
                                <?php $__currentLoopData = $optional; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="car-tick" data-feature="<?php echo e(strtolower($feature->name)); ?>"><?php echo e($feature->name); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if($standard->isNotEmpty()): ?>
                        <div class="car-feature-group" data-feature-group>
                            <header>Standard equipment</header>
                            <div>
                                <?php $__currentLoopData = $standard->take(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <p class="car-tick" data-feature="<?php echo e(strtolower($feature->name)); ?>"><?php echo e($feature->name); ?></p>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php if($standard->count() > 8): ?>
                                    <div data-features-extra hidden>
                                        <?php $__currentLoopData = $standard->slice(8); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p class="car-tick" data-feature="<?php echo e(strtolower($feature->name)); ?>"><?php echo e($feature->name); ?></p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php if($standard->count() > 8): ?>
                            <button class="car-more" type="button" data-features-more>View all <?php echo e($standard->count()); ?> standard features</button>
                        <?php endif; ?>
                    <?php endif; ?>
                </section>
            <?php endif; ?>

            <?php if($car->chargeTimes->isNotEmpty()): ?>
                <section class="car-card">
                    <h2>Charge times</h2>
                    <div class="car-specs">
                        <?php $__currentLoopData = $car->chargeTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <small><?php echo e($time->charger_type); ?></small>
                                <b><?php echo e($time->duration_minutes ? $time->duration_minutes.' min' : '—'); ?></b>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
            <?php endif; ?>

            <?php if($pounds): ?>
                <section class="car-card" id="finance-calculator" data-calculator>
                    <div class="car-section-head">
                        <div>
                            <h2>Illustrative finance example</h2>
                            <p>Adjust the deposit and term. This is not a finance offer.</p>
                        </div>
                    </div>
                    <div class="car-finance">
                        <div>
                            <input type="hidden" name="price" value="<?php echo e($pounds); ?>">
                            <label>Customer deposit <b data-deposit-label></b>
                                <input type="range" name="deposit" min="0" max="<?php echo e($pounds); ?>" step="50" value="<?php echo e(min(2500, $pounds)); ?>">
                            </label>
                            <label>Agreement term <b data-months-label>48 months</b>
                                <input type="range" name="months" min="24" max="60" step="12" value="48">
                            </label>
                        </div>
                        <div class="car-finance-result">
                            <small>Illustrative monthly payment</small>
                            <strong data-payment>—</strong>
                            <span>Assumed 12.9% annual rate</span>
                            <a class="car-btn primary" href="<?php echo e(route('finance', ['car' => $car->slug])); ?>">Ask about finance</a>
                            <p>This is an illustration, not a quote or a credit check.</p>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
        </div>

        <aside class="car-side">
            <div class="car-card car-buy">
                <small>Total online price</small>
                <strong><?php echo e(\App\Support\Money::gbp($price)); ?></strong>
                <p>Ready to view at the Dagenham showroom.</p>
                <div class="car-actions">
                    <form method="post" action="<?php echo e(route('cars.save', $car->slug)); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="car-btn" type="submit" data-save="<?php echo e($car->id); ?>" aria-label="<?php echo e($saved ? 'Unsave' : 'Save'); ?> <?php echo e($car->title()); ?>"><?php echo e($saved ? 'Saved' : 'Save this car'); ?></button>
                    </form>
                    <?php if($car->website_status === 'available'): ?>
                        <details id="reserve" <?php if($errors->any()): ?> open <?php endif; ?>>
                            <summary class="car-btn primary">Reserve this car</summary>
                            <form method="post" action="<?php echo e(route('cars.reserve', $car->slug)); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo $__env->make('partials.contact-fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                <label>Preferred date<input type="date" name="preferred_on" required value="<?php echo e(old('preferred_on')); ?>"></label>
                                <label>Notes<textarea name="notes"><?php echo e(old('notes')); ?></textarea></label>
                                <button class="car-btn primary" type="submit">Send reservation</button>
                            </form>
                        </details>
                    <?php endif; ?>
                    <details <?php if($errors->any()): ?> open <?php endif; ?>>
                        <summary class="car-btn">Book a viewing</summary>
                        <form method="post" action="<?php echo e(route('cars.viewing', $car->slug)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('partials.contact-fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <label>Date<input type="date" name="preferred_on" required value="<?php echo e(old('preferred_on')); ?>"></label>
                            <label>Time<input type="time" name="preferred_time" required value="<?php echo e(old('preferred_time')); ?>"></label>
                            <button class="car-btn primary" type="submit">Request viewing</button>
                        </form>
                    </details>
                    <details>
                        <summary class="car-btn">Request a test drive</summary>
                        <form method="post" action="<?php echo e(route('cars.test-drive', $car->slug)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('partials.contact-fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <label>Date<input type="date" name="preferred_on" required value="<?php echo e(old('preferred_on')); ?>"></label>
                            <label>Time<input type="time" name="preferred_time" required value="<?php echo e(old('preferred_time')); ?>"></label>
                            <button class="car-btn primary" type="submit">Request test drive</button>
                        </form>
                    </details>
                    <details>
                        <summary class="car-btn">Ask about this car</summary>
                        <form method="post" action="<?php echo e(route('cars.enquiry', $car->slug)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo $__env->make('partials.contact-fields', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            <label>Message<textarea name="message"><?php echo e(old('message')); ?></textarea></label>
                            <button class="car-btn primary" type="submit">Send enquiry</button>
                        </form>
                    </details>
                </div>
                <a class="car-exchange" href="<?php echo e(route('sell')); ?>">
                    <b>Have a car to part exchange?</b>
                    <span>Tell us about it and we can talk it through against this car.</span>
                </a>
                <div class="car-promises">
                    <h3>Included with this vehicle</h3>
                    <p>AA Approved Dealer</p>
                    <p>HPI checked</p>
                    <p>3-month warranty</p>
                    <p>12-month breakdown cover</p>
                    <p>5-day drive-away insurance</p>
                </div>
            </div>
            <div class="car-card car-visit">
                <h3>Visit the showroom</h3>
                <p><b>Ghani Motors</b></p>
                <p><?php echo e($dealer->address_line); ?>, <?php echo e($dealer->city); ?>, <?php echo e($dealer->postcode); ?></p>
                <?php if($phone): ?>
                    <a href="tel:+<?php echo e($phone); ?>">Call <?php echo e($dealer->phone); ?></a>
                <?php endif; ?>
            </div>
        </aside>
    </div>
</div>
<div class="car-mobile-bar">
    <div>
        <small><?php echo e($pounds ? 'Total price' : 'Enquire'); ?></small>
        <b>
            <?php if($pounds): ?>
                <?php echo e(\App\Support\Money::gbp($price)); ?>
            <?php else: ?>
                Ask for price
            <?php endif; ?>
        </b>
    </div>
    <div>
        <?php if($phone): ?>
            <a href="tel:+<?php echo e($phone); ?>" aria-label="Call the showroom">Call</a>
        <?php endif; ?>
        <?php if($car->website_status === 'available' && $pounds): ?>
            <button type="button" data-open-reserve>Reserve</button>
        <?php else: ?>
            <button type="button" data-enquiry-open>Enquire</button>
        <?php endif; ?>
    </div>
</div>
<dialog class="car-lightbox" data-lightbox>
    <button type="button" data-lightbox-close>Close</button>
    <img alt="" data-lightbox-image>
</dialog>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/site/car.blade.php ENDPATH**/ ?>