<div class="account-metrics">
    <a class="account-metric" href="<?php echo e(route('account', 'saved')); ?>">
        <span>Saved cars</span>
        <strong><?php echo e($counts['saved']); ?></strong>
        <small>Open full list</small>
    </a>
    <a class="account-metric" href="<?php echo e(route('account', 'bookings')); ?>">
        <span>Bookings</span>
        <strong><?php echo e($counts['bookings']); ?></strong>
        <small><?php echo e($counts['open_bookings']); ?> open</small>
    </a>
    <a class="account-metric" href="<?php echo e(route('account', 'enquiries')); ?>">
        <span>Enquiries</span>
        <strong><?php echo e($counts['enquiries']); ?></strong>
        <small>View all messages</small>
    </a>
    <a class="account-metric" href="<?php echo e(route('account', 'invoices')); ?>">
        <span>Invoices</span>
        <strong><?php echo e($counts['invoices']); ?></strong>
        <small><?php echo e($counts['sales']); ?> purchase<?php echo e($counts['sales'] === 1 ? '' : 's'); ?></small>
    </a>
</div>

<div class="account-split">
    <section class="account-card">
        <div class="account-card-head">
            <div>
                <h2>Recent bookings</h2>
                <p class="meta">Latest reservations and appointments.</p>
            </div>
            <a class="textlink" href="<?php echo e(route('account', 'bookings')); ?>">View all ↗</a>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $recentBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="account-item">
                <div>
                    <b><?php echo e(ucfirst(str_replace('_', ' ', $booking->type))); ?></b>
                    <p class="meta"><?php echo e($booking->vehicle?->title() ?: 'Car'); ?></p>
                    <small><?php echo e($booking->preferred_on?->format('j M Y')); ?></small>
                </div>
                <span class="badge <?php echo e($booking->status); ?>"><?php echo e(ucfirst($booking->status)); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="account-empty compact"><p>No bookings yet.</p><a class="textlink" href="<?php echo e(route('stock')); ?>">Browse stock ↗</a></div>
        <?php endif; ?>
    </section>

    <section class="account-card">
        <div class="account-card-head">
            <div>
                <h2>Recent alerts</h2>
                <p class="meta">Updates from the showroom.</p>
            </div>
            <a class="textlink" href="<?php echo e(route('account', 'alerts')); ?>">View all ↗</a>
        </div>
        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="account-alert <?php if(!$note->read_at): ?> is-unread <?php endif; ?>">
                <div>
                    <b><?php echo e($note->title); ?></b>
                    <?php if($note->body): ?><p class="meta"><?php echo e($note->body); ?></p><?php endif; ?>
                </div>
                <a class="btn smallbtn ghost" href="<?php echo e(route('account.notifications.read', $note)); ?>">Open</a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="account-empty compact"><p>No alerts yet.</p></div>
        <?php endif; ?>
    </section>
</div>

<section class="account-card">
    <div class="account-card-head">
        <div>
            <h2>Saved cars</h2>
            <p class="meta">A few of your favourites.</p>
        </div>
        <a class="textlink" href="<?php echo e(route('account', 'saved')); ?>">View all <?php echo e($counts['saved']); ?> ↗</a>
    </div>
    <?php if($recentSaved->isEmpty()): ?>
        <div class="account-empty">
            <p>You haven’t saved a car yet.</p>
            <a class="btn" href="<?php echo e(route('stock')); ?>">Find cars in stock</a>
        </div>
    <?php else: ?>
        <div class="account-saved-grid">
            <?php $__currentLoopData = $recentSaved; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('site.account.partials.saved-card', ['car' => $car], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
</section>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/site/account/overview.blade.php ENDPATH**/ ?>