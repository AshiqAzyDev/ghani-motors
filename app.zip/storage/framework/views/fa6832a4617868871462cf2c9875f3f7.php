<?php $__env->startSection('title', 'Reset password'); ?>
<?php $__env->startSection('content'); ?>
<section class="section"><div class="wrap" style="max-width:480px;">
    <div class="panel">
        <h1>Reset password</h1>
        <?php if(!empty($sent)): ?>
            <p>If that email has an account, a reset link has been sent.</p>
            <p style="margin-top:1rem;"><a class="textlink" href="<?php echo e(route('login')); ?>">← Back to log in</a></p>
        <?php else: ?>
            <form method="post" action="<?php echo e(route('password.email')); ?>">
                <?php echo csrf_field(); ?>
                <label>Email</label><input type="email" name="email" required value="<?php echo e(old('email')); ?>">
                <button class="btn" type="submit" style="margin-top:1rem;">Send reset link</button>
            </form>
            <p style="margin-top:1rem;"><a class="textlink" href="<?php echo e(route('login')); ?>">← Back to log in</a></p>
        <?php endif; ?>
    </div>
</div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/auth/forgot.blade.php ENDPATH**/ ?>