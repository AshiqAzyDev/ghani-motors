<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('content'); ?>
<section class="section about">
    <div>
        <div class="crumb"><a href="<?php echo e(route('home')); ?>">Home</a> / About us</div>
        <div class="eyebrow">Good cars. Real people.</div>
        <h2>A family business.<br>An AA Approved Dealer.</h2>
        <p>Based in <?php echo e($dealer->city ?: 'Dagenham'); ?>, <?php echo e($dealer->displayName()); ?> is a family-run, AA Approved Dealer focused on quality used cars and a friendly, straightforward buying experience.</p>
        <p><?php echo e($dealer->showroomAddress()); ?></p>
        <?php if($dealer->opening_hours): ?>
            <p><?php echo e($dealer->opening_hours); ?></p>
        <?php endif; ?>
        <?php if($dealer->phone): ?>
            <p><a class="textlink" href="tel:<?php echo e(preg_replace('/\s+/', '', $dealer->phone)); ?>"><?php echo e($dealer->phone); ?></a></p>
        <?php endif; ?>
        <?php if($dealer->publicEmail()): ?>
            <p><a class="textlink" href="mailto:<?php echo e($dealer->publicEmail()); ?>"><?php echo e($dealer->publicEmail()); ?></a></p>
        <?php endif; ?>
    </div>
    <div>
        <div class="benefit"><h3><span>01</span> Find the right fit</h3><p>Search by the things that matter to you, from price and mileage to transmission.</p></div>
        <div class="benefit"><h3><span>02</span> Make it yours</h3><p>Arrange a viewing, ask a question or explore finance with our team.</p></div>
        <div class="benefit"><h3><span>03</span> A simpler changeover</h3><p>Have a car to sell? Ask us about selling or part exchanging.</p></div>
    </div>
</section>
<?php echo $__env->make('partials.trust', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('partials.map', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.site', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Cloud Tech\ghani\resources\views/site/about.blade.php ENDPATH**/ ?>