<?php if($dealerStaff): ?>
<div class="notify-wrap" data-notify-root data-notify-url="<?php echo e(route('dealer.notifications.unread')); ?>">
    <button class="notify-bell" type="button" data-notify-toggle aria-label="Notifications" aria-expanded="false">
        <span aria-hidden="true">🔔</span>
        <span class="notify-count" data-notify-count hidden>0</span>
    </button>
    <div class="notify-panel" data-notify-panel hidden>
        <div class="notify-panel-head">
            <strong>Notifications</strong>
            <form method="post" action="<?php echo e(route('dealer.notifications.read-all')); ?>"><?php echo csrf_field(); ?><button class="rowbtn" type="submit">Mark all read</button></form>
        </div>
        <div data-notify-list class="notify-list"><p class="meta">Loading…</p></div>
        <a class="notify-foot" href="<?php echo e(route('dealer.notifications')); ?>">View all</a>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\Cloud Tech\ghani\resources\views/partials/dealer-notifications.blade.php ENDPATH**/ ?>